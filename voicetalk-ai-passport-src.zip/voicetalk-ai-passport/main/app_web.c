// main/app_web.c —— 网页设置(手机连 VoiceTalk-XXXX 热点,浏览器打开 192.168.4.1)。
//
// 网页负责设备端不好输的东西:汉字/英文用户名、6 位房号、4 位房间密码、
// Wi-Fi 密码。设备三键只管通话和几个常用设置。
//
// 两条硬规则(来自需求):
//   * 服务器地址在网页里填(域名或 IP),不写死在固件里;
//     留空则退回"局域网自动发现",因此没服务器也能正常对讲。
//   * 点"保存设置"就写入 NVS 并自动重启,让新配置立刻生效。
#include "app_web.h"

#include "app_audio.h"
#include "app_config.h"
#include "app_net.h"
#include "app_protocol.h"
#include "app_state.h"
#include "app_storage.h"
#include "bsp_display.h"

#include "esp_http_server.h"
#include "esp_log.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *TAG = "vt_web";
static httpd_handle_t s_server;
static char s_body[2048];

#define WEB_AP_IP "192.168.4.1"

const char *app_web_ap_ip(void) {
    return WEB_AP_IP;
}

bool app_web_running(void) {
    return s_server != NULL;
}

// —— 表单解码:application/x-www-form-urlencoded ——
static int hex_value(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

// 汉字在表单里是 %E4%B8%AD 这种形式,必须解回 UTF-8 才能存进 LVGL 能显示的配置。
static void urldecode(char *dst, size_t cap, const char *src, size_t len) {
    size_t o = 0;
    for (size_t i = 0; i < len && o + 1 < cap; i++) {
        if (src[i] == '+') {
            dst[o++] = ' ';
        } else if (src[i] == '%' && i + 2 < len) {
            int hi = hex_value(src[i + 1]);
            int lo = hex_value(src[i + 2]);
            if (hi >= 0 && lo >= 0) {
                dst[o++] = (char)((hi << 4) | lo);
                i += 2;
            } else {
                dst[o++] = src[i];
            }
        } else {
            dst[o++] = src[i];
        }
    }
    dst[o] = '\0';
}

static bool form_value(const char *body, const char *key, char *out, size_t cap) {
    size_t key_len = strlen(key);
    const char *p = body;
    while (*p) {
        bool at_start = (p == body) || (p[-1] == '&');
        if (at_start && strncmp(p, key, key_len) == 0 && p[key_len] == '=') {
            const char *v = p + key_len + 1;
            const char *end = strchr(v, '&');
            size_t len = end ? (size_t)(end - v) : strlen(v);
            urldecode(out, cap, v, len);
            return true;
        }
        p++;
    }
    return false;
}

// —— 页面 ——
static const char PAGE_HEAD[] =
    "<!DOCTYPE html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\">"
    "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
    "<title>VoiceTalk 对讲机设置</title><style>"
    "body{margin:0;padding:14px;background:#0e1116;color:#e8edf2;"
    "font-family:system-ui,-apple-system,\"Noto Sans SC\",sans-serif;}"
    "h1{font-size:18px;margin:0 0 12px;color:#f5a623;}"
    "h2{font-size:14px;margin:16px 0 8px;color:#94a1ae;border-bottom:1px solid #2a323c;"
    "padding-bottom:4px;}"
    ".card{background:#171c23;border:1px solid #2a323c;border-radius:6px;padding:10px;"
    "margin-bottom:10px;}"
    "label{display:block;font-size:12px;color:#94a1ae;margin:8px 0 4px;}"
    "input[type=text],input[type=password],select{width:100%;box-sizing:border-box;"
    "background:#0e1116;color:#e8edf2;border:1px solid #2a323c;border-radius:4px;"
    "padding:9px;font-size:16px;}"
    "input[type=range]{width:100%;}"
    ".row{display:flex;gap:8px;}"
    ".row>*{flex:1;}"
    ".val{float:right;color:#f5a623;}"
    "button{background:#f5a623;color:#0e1116;border:0;border-radius:4px;padding:11px 14px;"
    "font-size:15px;font-weight:600;width:100%;margin-top:14px;}"
    "button.mini{background:#2a323c;color:#e8edf2;font-weight:400;margin-top:6px;padding:7px;}"
    ".ro{color:#e8edf2;font-size:14px;}"
    ".hint{font-size:12px;color:#94a1ae;line-height:1.6;}"
    ".wifi{display:flex;justify-content:space-between;align-items:center;font-size:13px;"
    "padding:6px 0;border-bottom:1px dashed #2a323c;}"
    "</style></head><body><h1>VoiceTalk 对讲机设置</h1>";

// 发送一大段静态 HTML(分段发,避免一次拼太大的临时缓冲)。
static esp_err_t send_html(httpd_req_t *req, const char *html) {
    return httpd_resp_send(req, html, HTTPD_RESP_USE_STRLEN);
}

static void append_escaped(char *out, size_t cap, const char *value) {
    // 只转义 HTML 里真正危险的几个字符;用户名允许汉字,但要防 XSS 式注入。
    size_t used = strlen(out);
    for (const char *p = value; *p && used + 7 < cap; p++) {
        if (*p == '&') used += (size_t)snprintf(out + used, cap - used, "&amp;");
        else if (*p == '<') used += (size_t)snprintf(out + used, cap - used, "&lt;");
        else if (*p == '>') used += (size_t)snprintf(out + used, cap - used, "&gt;");
        else if (*p == '"') used += (size_t)snprintf(out + used, cap - used, "&quot;");
        else out[used++] = *p;
    }
    out[used] = '\0';
}

static esp_err_t index_handler(httpd_req_t *req) {
    app_state_lock();
    vt_config_t cfg = app_state()->cfg;
    char ssid[33];
    strncpy(ssid, app_state()->ssid, sizeof(ssid));
    char ip[16];
    strncpy(ip, app_state()->ip, sizeof(ip));
    vt_link_state_t link = app_state()->link;
    app_state_unlock();

    char room[VT_ROOM_DIGITS + 1];
    vt_format_room(cfg.room, room);
    char pass[VT_PASS_DIGITS + 4] = "";
    if (cfg.has_pass) snprintf(pass, sizeof(pass), "%04u", (unsigned)cfg.passcode);

    char *page = (char *)malloc(14336);
    if (!page) {
        httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "内存不足");
        return ESP_FAIL;
    }

    char name_esc[VT_NAME_MAX_BYTES * 8 + 1];
    name_esc[0] = '\0';
    append_escaped(name_esc, sizeof(name_esc), cfg.name);
    char ssid_esc[160];
    ssid_esc[0] = '\0';
    append_escaped(ssid_esc, sizeof(ssid_esc), ssid[0] ? ssid : "(未连接)");
    char srv_esc[VT_SERVER_HOST_MAX * 8 + 1];
    srv_esc[0] = '\0';
    append_escaped(srv_esc, sizeof(srv_esc), cfg.server_host);

    // 服务器状态:让用户在浏览器里就能判断"填的地址到底通没通"。
    vt_server_state_t srv_state;
    app_state_lock();
    srv_state = app_state()->server_state;
    app_state_unlock();
    const char *srv_text = "未配置(局域网自动发现)";
    if (cfg.transport != (uint8_t)VT_TRANSPORT_SERVER) {
        srv_text = "未使用(当前是局域网模式)";
    } else if (srv_state == VT_SERVER_ONLINE) {
        srv_text = "在线";
    } else if (srv_state == VT_SERVER_FAILED) {
        srv_text = "地址解析失败(已退回局域网)";
    } else if (srv_state == VT_SERVER_SEEKING) {
        srv_text = "寻找中";
    }

    int used = snprintf(page, 14336,
        "%s"
        "<div class=\"card\">"
        "<div class=\"ro\">当前 IP: <b>%s</b></div>"
        "<div class=\"ro\">当前 Wi-Fi: <b>%s</b></div>"
        "<div class=\"ro\">服务器状态: <b>%s</b></div>"
        "<div class=\"hint\">上面的 IP 只是告诉你设备现在在哪个网段。"
        "要跨互联网通话,在下面填中转服务器地址。</div>"
        "</div>"
        "<form method=\"post\" action=\"/save\">"
        "<h2>通话</h2>"
        "<div class=\"card\">"
        "<label>使用者名称(英文 / 数字 / 汉字,最多 %d 字节)</label>"
        "<input type=\"text\" name=\"name\" maxlength=\"%d\" value=\"%s\""
        " placeholder=\"例如:张三 / Fox01\">"
        "<label>房间号(6 位数字)</label>"
        "<input type=\"text\" name=\"room\" maxlength=\"6\" pattern=\"[0-9]{6}\""
        " inputmode=\"numeric\" value=\"%s\">"
        "<label>房间密码(4 位数字;留空 = 不加密。只在这里设置)</label>"
        "<input type=\"text\" name=\"pass\" maxlength=\"4\" pattern=\"[0-9]{4}\""
        " inputmode=\"numeric\" value=\"%s\" placeholder=\"留空\">"
        "</div>"
        "<h2>中转服务器(跨互联网通话)</h2>"
        "<div class=\"card\">"
        "<label>服务器地址(域名或 IP;留空 = 只在局域网里自动寻找)</label>"
        "<input type=\"text\" name=\"srv\" maxlength=\"64\" value=\"%s\""
        " placeholder=\"例如: voice.example.com 或 203.0.113.7\">"
        "<label>服务器端口(留空 = 8801)</label>"
        "<input type=\"text\" name=\"sport\" maxlength=\"5\" inputmode=\"numeric\""
        " value=\"%u\" placeholder=\"8801\">"
        "<div class=\"hint\">填了地址后,设备解析域名并把语音发到那里,"
        "这样不同 Wi-Fi、不同城市的设备也能互相通话;解析不到时自动退回局域网。"
        "服务器上需要运行 tools/voice_relay_server.py,并放通对应的 UDP 端口。</div>"
        "</div>"
        "<h2>设备</h2>"
        "<div class=\"card\">"
        "<label>设备音量 <span class=\"val\" id=\"vv\">%u%%</span></label>"
        "<input type=\"range\" name=\"volume\" min=\"0\" max=\"100\" value=\"%u\""
        " oninput=\"document.getElementById('vv').textContent=this.value+'%%'\">"
        "<label>传输方式</label>"
        "<select name=\"transport\">"
        "<option value=\"0\"%s>局域网广播(同一 Wi-Fi 直连)</option>"
        "<option value=\"1\"%s>服务器中转(填了地址可跨互联网)</option>"
        "</select>"
        "</div>"
        "<h2>Wi-Fi</h2>"
        "<div class=\"card\">",
        PAGE_HEAD,
        ip[0] ? ip : "(未分配)",
        ssid_esc,
        srv_text,
        VT_NAME_MAX_BYTES, VT_NAME_MAX_BYTES, name_esc,
        room, pass,
        srv_esc, (unsigned)cfg.server_port,
        (unsigned)cfg.volume, (unsigned)cfg.volume,
        cfg.transport == (uint8_t)VT_TRANSPORT_SERVER ? "" : " selected",
        cfg.transport == (uint8_t)VT_TRANSPORT_SERVER ? " selected" : "");

    for (uint8_t i = 0; i < cfg.wifi_count && used < 9000; i++) {
        char line[384];
        char esc[160];
        esc[0] = '\0';
        append_escaped(esc, sizeof(esc), cfg.wifi[i].ssid);
        snprintf(line, sizeof(line),
                 "<div class=\"wifi\"><span>%s</span>"
                 "<button class=\"mini\" type=\"submit\" name=\"del\" value=\"%u\">删除</button>"
                 "</div>",
                 esc, (unsigned)i);
        size_t len = strlen(line);
        if (used + (int)len < 10000) {
            memcpy(page + used, line, len);
            used += (int)len;
            page[used] = '\0';
        }
    }

    used += snprintf(page + used, 14336 - (size_t)used,
        "<label>搜索附近 Wi-Fi</label>"
        "<div class=\"row\"><button class=\"mini\" type=\"button\" onclick=\"scanWifi()\">扫描 Wi-Fi</button></div>"
        "<select id=\"wifi-list\" onchange=\"document.getElementById('ssid-input').value=this.value\"><option value=\"\">点击扫描后选择网络</option></select>"
        "<div class=\"hint\" id=\"scan-status\">扫描结果会显示信号强度；选择后填写密码并保存。</div>"
        "<label>Wi-Fi 名称(可手动输入)</label>"
        "<input id=\"ssid-input\" type=\"text\" name=\"ssid\" maxlength=\"32\" placeholder=\"SSID\">"
        "<label>密码(开放网络请留空)</label>"
        "<input type=\"password\" name=\"wifipass\" maxlength=\"64\" placeholder=\"留空 = 开放网络\">"
        "</div>"
        "<button type=\"submit\">保存设置(设备会自动重启)</button>"
        "</form>"
        "<div class=\"hint\" style=\"margin-top:14px\">"
        "房间最多容纳 %u 人;房号与密码相同的设备才会互通。"
        "设备端设置页可以改屏幕亮度、设备音量、传输方式、打开本网页、还原出厂值。</div>"
        "<script>async function scanWifi(){const st=document.getElementById('scan-status'),sel=document.getElementById('wifi-list');st.textContent='正在扫描附近 Wi-Fi…';try{const r=await fetch('/scan',{cache:'no-store'});if(!r.ok)throw new Error('扫描失败');const a=await r.json();sel.innerHTML='';if(!a.length){st.textContent='没有发现 Wi-Fi，请靠近路由器后重试。';return;}a.forEach(x=>{const o=document.createElement('option');o.value=x.ssid;o.textContent=x.ssid+' · '+x.rssi+' dBm · '+(x.rssi>-55?'强':x.rssi>-70?'中':'弱');sel.appendChild(o);});document.getElementById('ssid-input').value=sel.value;st.textContent='发现 '+a.length+' 个网络，按信号强度排序。';}catch(e){st.textContent='扫描失败，请稍后重试；也可手动输入 Wi-Fi 名称。';}}</script>"
        "</body></html>",
        (unsigned)VT_ROOM_MAX_MEMBERS);

    esp_err_t err = send_html(req, page);
    free(page);
    (void)link;
    return err;
}

// 保存后延迟重启:先让 HTTP 响应发完,再复位。
static void restart_task(void *arg) {
    (void)arg;
    vTaskDelay(pdMS_TO_TICKS(1200));
    app_net_shutdown();
    vTaskDelay(pdMS_TO_TICKS(200));
    esp_restart();
}

static esp_err_t save_handler(httpd_req_t *req) {
    if (req->content_len >= (int)sizeof(s_body)) {
        httpd_resp_send_err(req, HTTPD_414_URI_TOO_LONG, "提交内容太大");
        return ESP_FAIL;
    }
    int total = 0;
    int received;
    while (total < req->content_len) {
        received = httpd_req_recv(req, s_body + total, req->content_len - total);
        if (received <= 0) {
            httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "读取失败");
            return ESP_FAIL;
        }
        total += received;
    }
    s_body[total] = '\0';

    app_state_lock();
    vt_config_t cfg = app_state()->cfg;
    app_state_unlock();

    char field[256];

    // 1) 删除某条 Wi-Fi
    if (form_value(s_body, "del", field, sizeof(field))) {
        int index = atoi(field);
        if (index >= 0 && index < cfg.wifi_count) {
            vt_config_wifi_remove(&cfg, (uint8_t)index);
        }
    } else {
        // 2) 常规字段
        if (form_value(s_body, "name", field, sizeof(field))) {
            if (!vt_config_check_name(field)) {
                httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST,
                                    "使用者名称不合法:只能是英文/数字/汉字,且不为空");
                return ESP_FAIL;
            }
            strncpy(cfg.name, field, VT_NAME_MAX_BYTES);
            cfg.name[VT_NAME_MAX_BYTES] = '\0';
        }
        if (form_value(s_body, "room", field, sizeof(field))) {
            uint32_t room = 0;
            if (!vt_config_check_room(field, &room)) {
                httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "房间号必须是 6 位数字");
                return ESP_FAIL;
            }
            cfg.room = room;
        }
        if (form_value(s_body, "pass", field, sizeof(field))) {
            uint16_t code = 0;
            bool has = false;
            if (!vt_config_check_pass(field, &code, &has)) {
                httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST,
                                    "房间密码必须是 4 位数字(留空表示不加密)");
                return ESP_FAIL;
            }
            cfg.passcode = code;
            cfg.has_pass = has;
        }
        if (form_value(s_body, "volume", field, sizeof(field))) {
            int value = atoi(field);
            if (value < 0) value = 0;
            if (value > 100) value = 100;
            cfg.volume = (uint8_t)value;
        }
        if (form_value(s_body, "transport", field, sizeof(field))) {
            cfg.transport = (strcmp(field, "1") == 0) ? (uint8_t)VT_TRANSPORT_SERVER
                                                      : (uint8_t)VT_TRANSPORT_LAN;
        }
        // 中转服务器:留空 = 不指定,设备退回局域网广播发现。
        if (form_value(s_body, "srv", field, sizeof(field))) {
            if (!vt_config_check_host(field)) {
                httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST,
                                    "服务器地址不合法:只能填域名或 IP"
                                    "(字母/数字/-/./_),或不填表示不指定服务器");
                return ESP_FAIL;
            }
            strncpy(cfg.server_host, field, VT_SERVER_HOST_MAX);
            cfg.server_host[VT_SERVER_HOST_MAX] = '\0';
        }
        if (form_value(s_body, "sport", field, sizeof(field))) {
            uint16_t port = 0;
            if (!vt_config_check_port(field, &port)) {
                httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST,
                                    "服务器端口必须是 1..65535 的数字(留空 = 8801)");
                return ESP_FAIL;
            }
            cfg.server_port = port;
        }
        // Wi-Fi:名称非空才写入(密码可空 = 开放网络)
        char ssid[VT_WIFI_SSID_MAX + 1];
        if (form_value(s_body, "ssid", ssid, sizeof(ssid)) && ssid[0] != '\0') {
            char pass[VT_WIFI_PASS_MAX + 1];
            if (!form_value(s_body, "wifipass", pass, sizeof(pass))) pass[0] = '\0';
            if (!vt_config_wifi_add(&cfg, ssid, pass)) {
                httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST,
                                    "Wi-Fi 保存失败:列表已满(最多 5 条)或密码太短");
                return ESP_FAIL;
            }
        }
    }

    // 立刻生效的部分(不等重启):音量与亮度在网页里改了要马上听得到/看得到。
    app_audio_set_volume(cfg.volume);
    bsp_display_backlight(cfg.brightness);

    esp_err_t err = app_storage_save(&cfg);
    if (err != ESP_OK) {
        httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "写入配置失败");
        return ESP_FAIL;
    }

    app_state_lock();
    app_state()->cfg = cfg;
    app_state_unlock();

    ESP_LOGI(TAG, "网页保存配置:名称=%s 房号=%06u 加密=%d 音量=%u%% 传输=%u 服务器=%s:%u",
             cfg.name[0] ? cfg.name : "(空)", (unsigned)cfg.room,
             (int)cfg.has_pass, (unsigned)cfg.volume, (unsigned)cfg.transport,
             cfg.server_host[0] ? cfg.server_host : "(未指定)",
             (unsigned)cfg.server_port);

    httpd_resp_set_type(req, "text/html; charset=utf-8");
    httpd_resp_send(req,
        "<!DOCTYPE html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\">"
        "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
        "<title>已保存</title><style>body{background:#0e1116;color:#e8edf2;"
        "font-family:system-ui,sans-serif;padding:24px;line-height:1.8}"
        "b{color:#3ddc84}</style></head><body>"
        "<h2><b>已保存</b></h2><p>设备正在重启,新设置即将生效。</p>"
        "<p style=\"color:#94a1ae;font-size:13px\">重启后请回到设备热点或原来的 Wi-Fi,"
        "在设备上确认房间号与在线人数。</p></body></html>",
        HTTPD_RESP_USE_STRLEN);

    xTaskCreate(restart_task, "vt_restart", 3072, NULL, 5, NULL);
    return ESP_OK;
}

/* 扫描附近无线网络并返回按 RSSI 从强到弱排序的 JSON。 */
static esp_err_t scan_handler(httpd_req_t *req) {
    wifi_scan_config_t scan_cfg = { 0 };
    esp_err_t err = esp_wifi_scan_start(&scan_cfg, true);
    if (err != ESP_OK) {
        httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "Wi-Fi 扫描启动失败");
        return err;
    }
    uint16_t count = 0;
    err = esp_wifi_scan_get_ap_num(&count);
    if (err != ESP_OK) {
        httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "读取扫描结果失败");
        return err;
    }
    if (count > 30) count = 30;
    wifi_ap_record_t *records = count ? calloc(count, sizeof(*records)) : NULL;
    if (count && !records) {
        httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "内存不足");
        return ESP_ERR_NO_MEM;
    }
    if (count) {
        uint16_t got = count;
        err = esp_wifi_scan_get_ap_records(&got, records);
        if (err != ESP_OK) { free(records); httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "读取扫描结果失败"); return err; }
        count = got;
        for (uint16_t i = 0; i < count; i++) for (uint16_t j = i + 1; j < count; j++) {
            if (records[j].rssi > records[i].rssi) { wifi_ap_record_t t = records[i]; records[i] = records[j]; records[j] = t; }
        }
    }
    httpd_resp_set_type(req, "application/json; charset=utf-8");
    httpd_resp_set_hdr(req, "Cache-Control", "no-store");
    httpd_resp_sendstr_chunk(req, "[");
    for (uint16_t i = 0; i < count; i++) {
        char item[180];
        char escaped[100] = {0}; size_t o = 0;
        for (const unsigned char *c = records[i].ssid; *c && o + 7 < sizeof(escaped); c++) {
            if (*c == '"' || *c == '\\') { escaped[o++] = '\\'; escaped[o++] = (char)*c; }
            else if (*c < 0x20) { o += (size_t)snprintf(escaped + o, sizeof(escaped) - o, "\\u%04x", *c); }
            else escaped[o++] = (char)*c;
        }
        escaped[o] = '\0';
        snprintf(item, sizeof(item), "%s{\"ssid\":\"%s\",\"rssi\":%d}", i ? "," : "", escaped, records[i].rssi);
        httpd_resp_sendstr_chunk(req, item);
    }
    httpd_resp_sendstr_chunk(req, "]");
    httpd_resp_sendstr_chunk(req, NULL);
    free(records);
    return ESP_OK;
}

static const httpd_uri_t URI_SCAN = {
    .uri = "/scan", .method = HTTP_GET, .handler = scan_handler, .user_ctx = NULL
};

static const httpd_uri_t URI_INDEX = {
    .uri = "/", .method = HTTP_GET, .handler = index_handler, .user_ctx = NULL
};
static const httpd_uri_t URI_SAVE = {
    .uri = "/save", .method = HTTP_POST, .handler = save_handler, .user_ctx = NULL
};

esp_err_t app_web_start(void) {
    if (s_server) return ESP_OK;

    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = 80;
    config.uri_match_fn = httpd_uri_match_wildcard;
    config.stack_size = 8192;      // 页面里要拼 8 KB 的 HTML,默认栈不够
    config.max_uri_handlers = 8;
    config.lru_purge_enable = true;

    esp_err_t err = httpd_start(&s_server, &config);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "HTTP 服务器启动失败: %s", esp_err_to_name(err));
        s_server = NULL;
        return err;
    }
    httpd_register_uri_handler(s_server, &URI_INDEX);
    httpd_register_uri_handler(s_server, &URI_SAVE);
    err = httpd_register_uri_handler(s_server, &URI_SCAN);
    if (err != ESP_OK) ESP_LOGW(TAG, "注册 Wi-Fi 扫描接口失败: %s", esp_err_to_name(err));
    ESP_LOGI(TAG, "网页设置已启动: http://%s", WEB_AP_IP);
    return ESP_OK;
}

void app_web_stop(void) {
    if (!s_server) return;
    httpd_stop(s_server);
    s_server = NULL;
}

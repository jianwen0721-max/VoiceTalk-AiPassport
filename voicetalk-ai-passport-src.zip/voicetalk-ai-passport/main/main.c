// main/main.c —— VoiceTalk 对讲机:初始化 + 按键分发 + 各模块装配。
//
// 应用结构(与基线 demo 无关,界面全部重写):
//   app_ui.c     通话页 / 成员页 / 设置页(硬派对讲机风格)
//   app_audio.c  半双工语音:按住 OK 发话,收到同伴语音就播
//   app_net.c    Wi-Fi、UDP 线路、中转服务器发现、NTP 校时
//   app_web.c    网页设置(名称/房号/密码/Wi-Fi,保存后自动重启)
//   app_state.c  运行时状态,上面几个模块共享
//
// 按键回调运行在共享 esp_timer 任务里:只入队,不做重活。
#include "app_audio.h"
#include "app_net.h"
#include "app_state.h"
#include "app_storage.h"
#include "app_ui.h"
#include "app_web.h"
#include "bsp_audio.h"
#include "bsp_battery.h"
#include "bsp_button.h"
#include "bsp_display.h"
#include "bsp_i2c.h"
#include "bsp_pins.h"
#include "key_guard.h"

#include "esp_log.h"
#include "esp_sleep.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "lvgl.h"

#include <string.h>

static const char *TAG = "voicetalk";

typedef struct {
    bsp_btn_t btn;
    bsp_btn_ev_t event;
} input_event_t;

#define INPUT_QUEUE_DEPTH 12
static QueueHandle_t s_input_queue;
static TaskHandle_t s_input_task;
static volatile bool s_input_ready;

// 按键从深睡唤醒时,那颗键在整个启动期间还按着:按键组件晚几百毫秒才起来,
// 一上来就看到一个已按下的电平,并会在按住满 500ms 时判成长按,于是开机立刻
// 触发一次意料外的动作(本应用里就是误发话)。守卫在唤醒键松手前吞掉所有动作。
// 状态机在 key_guard.h,便于脱离硬件做 host 测试。
#define KEY_GUARD_MAX_US (10LL * 1000 * 1000)
static key_guard_t s_key_guard;

static void process_input(const input_event_t *input) {
    // PTT 不走 UI:按下/松开要立刻切换音频,不能排在 LVGL 锁后面等刷新。
    // 通话页之外的页面不响应 PTT,免得在设置里误触发话。
    if (input->btn == BSP_BTN_OK &&
        (input->event == BSP_BTN_PRESS || input->event == BSP_BTN_RELEASE)) {
        if (app_ui_page() != VT_PAGE_TALK) return;
        if (input->event == BSP_BTN_PRESS) app_audio_start_tx();
        else app_audio_stop_tx();
        return;
    }

    if (!bsp_lvgl_lock(200)) return;
    app_ui_handle_key(input->btn, input->event);
    bsp_lvgl_unlock();
}

static void input_task(void *arg) {
    (void)arg;
    input_event_t input;
    for (;;) {
        if (xQueueReceive(s_input_queue, &input, portMAX_DELAY) == pdTRUE) {
            process_input(&input);
        }
    }
}

static void on_key(bsp_btn_t btn, bsp_btn_ev_t ev, void *user) {
    (void)user;
    // 先过守卫再判就绪:松手事件可能出现在"启动后电压采样"之前、
    // "输入分发就绪"之后,若被下面的 return 直接丢掉,守卫会一直武装到兜底,
    // 把下一次真实按键也吞掉。
    const bool was_armed = s_key_guard.armed;
    if (key_guard_consume(&s_key_guard, ev == BSP_BTN_RELEASE, esp_timer_get_time())) {
        if (was_armed && !s_key_guard.armed) {
            ESP_LOGI(TAG, "唤醒键已松手,按键恢复响应");
        }
        return;
    }
    if (!s_input_ready || !s_input_queue) return;   // 启动阶段先把按键挡掉
    const input_event_t input = { .btn = btn, .event = ev };
    (void)xQueueSend(s_input_queue, &input, 0);
}

void app_main(void) {
    ESP_LOGI(TAG, "VoiceTalk 对讲机启动");

    const uint32_t wake_causes = esp_sleep_get_wakeup_causes();
    if (wake_causes & ~(1u << ESP_SLEEP_WAKEUP_UNDEFINED)) {
        ESP_LOGI(TAG, "休眠唤醒原因位图: 0x%02x", (unsigned)wake_causes);
    }
    // 按键唤醒时那颗键还按着,先屏蔽动作,直到它松手(见 on_key)。
    if (wake_causes & (1u << ESP_SLEEP_WAKEUP_GPIO)) {
        key_guard_arm(&s_key_guard, esp_timer_get_time(), KEY_GUARD_MAX_US);
        ESP_LOGI(TAG, "按键唤醒:先屏蔽按键动作,直到那颗键松手");
    }

    bsp_i2c_init();

    // 1) 配置:先读出来,后面所有模块都按它初始化。
    if (app_storage_init() != ESP_OK) {
        ESP_LOGW(TAG, "NVS 不可用,本次使用出厂默认值(设置不会被保存)");
    }
    app_state_init();
    vt_config_t cfg;
    vt_config_defaults(&cfg);
    if (app_storage_load(&cfg) != ESP_OK) {
        ESP_LOGW(TAG, "读取配置失败,使用出厂默认值");
    }
    app_state_lock();
    app_state()->cfg = cfg;
    app_state_unlock();

    // 2) 显示 + LVGL:没有屏幕这个应用就没有意义,失败直接停。
    if (bsp_display_init() != ESP_OK || !bsp_lvgl_init()) {
        ESP_LOGE(TAG, "显示/LVGL 初始化失败,检查 SPI 接线(MOSI=%d SCLK=%d CS=%d DC=%d BL=%d)",
                 BSP_LCD_MOSI, BSP_LCD_SCLK, BSP_LCD_CS, BSP_LCD_DC, BSP_LCD_BL);
        return;
    }
    bsp_display_backlight(cfg.brightness);

    // 3) 其余外设:单项失败不拖垮整个应用,界面上会降级显示。
    if (bsp_audio_init() != ESP_OK) ESP_LOGW(TAG, "音频初始化失败,通话不可用");
    if (bsp_battery_init() != ESP_OK) ESP_LOGW(TAG, "电量计不可用,电量显示 --");

    // 4) 按键分发
    s_input_queue = xQueueCreate(INPUT_QUEUE_DEPTH, sizeof(input_event_t));
    if (s_input_queue &&
        xTaskCreate(input_task, "vt_input", 3072, NULL, 5, &s_input_task) == pdPASS) {
        if (bsp_button_init(on_key, NULL) != ESP_OK) {
            ESP_LOGE(TAG, "按键初始化失败");
        } else if (s_key_guard.armed) {
            // 若唤醒键在按键驱动起来之前就松了手,驱动从头到尾没看到按下,
            // 永远不会发 release,守卫会白拦到兜底。按真实电压同步一次。
            const bool released = bsp_button_read_mv() >= BSP_BTN_MV_RELEASED_MIN;
            key_guard_sync_released(&s_key_guard, released);
            if (!s_key_guard.armed) {
                ESP_LOGI(TAG, "唤醒键在按键驱动启动前已松手,提前撤防");
            }
        }
    } else {
        ESP_LOGE(TAG, "按键事件队列创建失败");
    }

    // 5) 界面
    if (bsp_lvgl_lock(1000)) {
        app_ui_init();
        bsp_lvgl_unlock();
        s_input_ready = true;
    }

    // 6) 音频与网络
    if (app_audio_start(cfg.volume) != ESP_OK) {
        ESP_LOGE(TAG, "音频任务启动失败");
    }
    if (app_net_start() != ESP_OK) {
        ESP_LOGE(TAG, "网络启动失败,只能本机操作");
    }

    ESP_LOGI(TAG, "就绪:房间 %06u 名称=%s 传输=%s",
             (unsigned)cfg.room, cfg.name[0] ? cfg.name : "(未设置)",
             cfg.transport == 1 ? "服务器中转" : "局域网");
}

// main/app_ui.h —— 对讲机风格界面:通话页 / 成员页 / 设置页。
//
// 页面与按键(三键硬派操作,长按只用于发话,不再用来返回):
//   通话页   按住 OK = 发话;松开 = 结束
//            短按 UP  = 进设置页
//            短按 DOWN = 看房间成员
//   成员页   短按 UP/DOWN/OK = 回通话页
//   设置页   UP/DOWN 移动;OK 短按 = 进入编辑 / 执行;
//            编辑态 UP/DOWN 改值,再按 OK 保存并退出编辑(长按不再返回)
#pragma once

#include "bsp_button.h"

#include "esp_err.h"

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    VT_PAGE_TALK = 0,
    VT_PAGE_MEMBERS,
    VT_PAGE_SETTINGS,
} vt_page_t;

// 建界面并显示通话页。必须在 LVGL 就绪后、持 bsp_lvgl_lock() 调用。
esp_err_t app_ui_init(void);

// 按键分发。返回 true 表示界面已消费该事件。
// 必须在 bsp_lvgl_lock() 内调用(内部会改 LVGL 对象)。
bool app_ui_handle_key(bsp_btn_t btn, bsp_btn_ev_t ev);

vt_page_t app_ui_page(void);

// 切回通话页(例如网页保存后重启前、或设置里选了返回)。
void app_ui_show_talk(void);

#ifdef __cplusplus
}
#endif

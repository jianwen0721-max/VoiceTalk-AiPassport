// main/app_state.h —— 应用运行时状态(网络任务 / 音频任务 / UI / 网页共享)。
//
// 访问约定:
//   * app_state() 返回的指针只在 app_state_lock() 与 app_state_unlock() 之间有效使用。
//   * LVGL 只能在持 bsp_lvgl_lock() 时操作;本锁保护的是 C 数据,不要混用。
//   * 按键回调里不要读这里的状态做重活,发事件给应用任务即可。
#pragma once

#include "app_config.h"
#include "app_protocol.h"
#include "app_roster.h"

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Wi-Fi 状态
typedef enum {
    VT_LINK_DOWN = 0,     // 没连上(没配置 / 正在连 / 失败)
    VT_LINK_CONNECTING,
    VT_LINK_UP,           // 已连上 AP 且拿到 IP
} vt_link_state_t;

// 中转服务器状态 —— 只描述"设备眼里"的服务器,不代表服务器本身健康。
// NONE 与 FAILED 都还能通话:设备会自动退回局域网广播。
typedef enum {
    VT_SERVER_NONE = 0,   // 没填服务器地址
    VT_SERVER_SEEKING,    // 填了地址,还没解析出来,或还没收到回音
    VT_SERVER_FAILED,     // DNS 解析失败(地址填错 / DNS 服务器不可达)
    VT_SERVER_ONLINE,     // 收到服务器应答,或收到它转来的同伴语音
} vt_server_state_t;

typedef struct {
    vt_config_t cfg;      // 持久化配置(改名/换房后由网页或设置页更新)
    vt_roster_t roster;   // 房间成员

    uint16_t self_id;     // 本机 sender id(开机生成)

    // —— 网络 ——
    vt_link_state_t link;
    char ssid[33];        // 当前连接的 Wi-Fi 名称
    char ip[16];          // 当前 IP(点分十进制)
    int8_t rssi;
    bool ap_on;           // 网页设置热点是否开着
    bool relay_seen;      // 是否发现了中转服务器(局域网广播发现)
    uint32_t relay_addr;  // 中转服务器地址(网络序由调用方解释)
    uint16_t relay_port;

    // —— 互联网中转服务器(网页填的地址,DNS 解析)——
    vt_server_state_t server_state;
    uint32_t server_addr;     // 解析出的地址(网络序),0 = 尚未解析
    uint16_t server_port;     // 实际使用的端口
    uint32_t server_last_rx;  // 最近一次收到服务器侧报文的时刻(ms)

    // —— 通话 ——
    bool talking;         // 本机正在发话(按住 OK)
    uint16_t speaker_id;  // 当前发话者(0 = 无人);由 UI 每次刷新时算
    uint8_t online;       // 房间内在线人数(含自己)

    // —— 设备 ——
    int battery_soc;      // -1 = 读不到
    bool time_valid;      // NTP 是否已校时
} app_state_t;

// 进程内单例。main 启动时调用一次 app_state_init()。
void app_state_init(void);
app_state_t *app_state(void);
void app_state_lock(void);
void app_state_unlock(void);

#ifdef __cplusplus
}
#endif

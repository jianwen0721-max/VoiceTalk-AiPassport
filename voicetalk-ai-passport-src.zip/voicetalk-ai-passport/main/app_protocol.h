// main/app_protocol.h —— VoiceTalk 对讲机线路协议(纯逻辑,可在主机上单测)。
//
// 协议目标:让多台设备在同一"房间号"里半双工对讲,可走局域网广播,也可走
// UDP 中转服务器(跨网段)。本文件只定义字节布局与编解码,不涉及 socket、
// LVGL、FreeRTOS,因此 tests/test_app_protocol.c 可以直接编译运行。
//
// v2 变更(相对 v1 的 12 字节头):
//   * 房间号扩到 4 字节 —— 需求要求 6 位十进制房号(最大 999999),v1 的
//     2 字节房号最多 65535,放不下。
//   * 新增 flags 字段:bit0 表示房间带密码,AUDIO 载荷为加密后的密文。
//   * 新增 DISCOVER / SERVER_HERE:设备用广播找中转服务器,网页不再让
//     用户手填服务器地址(v1 是手填 IP)。
//   * 新增 TIME:中转服务器/已对时设备给同伴校时。
//
// ⚠ v1 与 v2 不互通:刷本固件的所有设备必须一起升级,中转服务器也要换成
//   tools/voice_relay_server.py 的新版本。
#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// magic 'V' 'T'
#define VT_MAGIC0 0x56u
#define VT_MAGIC1 0x54u
#define VT_VERSION 2u

// 固定头长度:2 magic + 1 version + 1 type + 4 room + 2 sender + 2 seq + 2 len + 2 flags
#define VT_HEADER_SIZE 16u

// 一帧语音:8 kHz / 16 bit / 单声道 / 20 ms = 160 采样 = 320 字节。
// 选 8 kHz 而不是 16 kHz:对讲机要的是可懂度和低延迟,C3 无 PSRAM,
// 每包 320 字节在 32 人房间里转发也不至于把带宽和内存打满。
#define VT_AUDIO_FRAME_BYTES 320u
#define VT_AUDIO_SAMPLE_HZ 8000u

// 载荷上限:语音帧 320 字节,控制包(HELLO 等)远小于此。
#define VT_MAX_PAYLOAD 320u

// 房间容量上限。32 是内存/带宽与可用的折中:sender 是 16 位(理论 65535),
// 但每台设备都要维护一张成员表,语音转发也随人数线性增长。
#define VT_ROOM_MAX_MEMBERS 32u

// 房号:6 位十进制数字 000000..999999。
#define VT_ROOM_MIN 0u
#define VT_ROOM_MAX 999999u
#define VT_ROOM_DIGITS 6u

// 用户名:UTF-8,允许英文/数字/汉字;按字节计数,汉字最多占 3 字节。
// 20 字节 ≈ 6 个汉字或 20 个英文字母,足够屏幕上显示且不会撑爆 HELLO 包。
#define VT_NAME_MAX_BYTES 20u
#define VT_NAME_MIN_BYTES 1u

// 房间密码:固定 4 位十进制数字(仅网页设置)。
#define VT_PASS_DIGITS 4u
#define VT_PASS_MAX 9999u

// 包类型
typedef enum {
    VT_PKT_HELLO = 1,        // 上线/心跳:载荷 = 1 字节名字长度 + 名字 + 4 字节房间密钥
    VT_PKT_BYE = 2,          // 下线
    VT_PKT_AUDIO = 3,        // 语音帧
    VT_PKT_AUDIO_END = 4,    // 一次发话结束(让对端立刻停播,不必等超时)
    VT_PKT_DISCOVER = 5,     // 设备广播:中转服务器在吗?
    VT_PKT_SERVER_HERE = 6,  // 服务器应答:我在这个端口(载荷 2 字节端口,大端)
} vt_pkt_type_t;

// flags 位
#define VT_FLAG_ENCRYPTED 0x0001u  // 房间有密码,AUDIO 载荷已用房间密钥加扰

// 房间密钥:由 4 位数字密码派生出的 32 位值。无密码房间为 0。
uint32_t vt_room_key(uint32_t room, uint16_t passcode, bool has_pass);

// 把 4 位数字密码解析成整数;字符串必须是恰好 4 个 '0'..'9'。
bool vt_parse_passcode(const char *text, uint16_t *out);

// 把 6 位数字房号解析成整数;字符串必须是恰好 6 个 '0'..'9'。
bool vt_parse_room(const char *text, uint32_t *out);

// 把房号格式化成 6 位定宽字符串(末尾补 '\0',需要 7 字节缓冲)。
void vt_format_room(uint32_t room, char out[VT_ROOM_DIGITS + 1]);

// 用户名校验:非空、不超过 VT_NAME_MAX_BYTES、UTF-8 合法、不含控制字符、
// 且必须包含至少一个"可见"字符(纯空格不算)。
bool vt_validate_name(const char *utf8, size_t len);

// 统计 UTF-8 字符串的字符数(非字节数);遇到非法序列返回 -1。
// 用于网页/设备端提示"还能输入几个字"。
int vt_utf8_length(const char *utf8, size_t len);

// —— 编解码 ——
// 成功返回写入/读出的总字节数(头+载荷),参数非法返回 0 或 -1。
// encode 需要 out 至少 VT_HEADER_SIZE + payload_len 字节。
size_t vt_encode(uint8_t *out, size_t out_cap, vt_pkt_type_t type, uint32_t room,
                 uint16_t sender, uint16_t seq, uint16_t flags,
                 const void *payload, uint16_t payload_len);

typedef struct {
    uint8_t version;
    vt_pkt_type_t type;
    uint32_t room;
    uint16_t sender;
    uint16_t seq;
    uint16_t flags;
    uint16_t payload_len;
    const uint8_t *payload;  // 指向入参缓冲内部,不拷贝
} vt_packet_t;

bool vt_decode(const uint8_t *buf, size_t len, vt_packet_t *out);

// HELLO 载荷编解码:1 字节名字长度 + 名字 + 4 字节大端房间密钥。
size_t vt_encode_hello(uint8_t *out, size_t out_cap, const char *name, uint32_t key);
bool vt_decode_hello(const uint8_t *payload, uint16_t len, char *name_out,
                     size_t name_cap, uint32_t *key_out);

// 语音加扰:同一个房间密钥下可逆。目的不是防窃听,而是让"密码不对"的
// 设备听不懂内容(对讲场景的轻量隔离,不替代真加密)。
void vt_scramble(uint8_t *data, uint16_t len, uint32_t key, uint16_t seq);

#ifdef __cplusplus
}
#endif

// main/app_roster.h —— 房间成员表(纯逻辑,可在主机上单测)。
//
// 每个房间最多 VT_ROOM_MAX_MEMBERS(32)人。表本身不含任何 IDF/LVGL 依赖,
// 由网络任务更新、由 UI 任务读取,因此读写都要在调用方持有的锁内完成。
#pragma once

#include "app_protocol.h"

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// 多久没收到某人的 HELLO 就认为他离线。HELLO 每 2 秒发一次,给 3 倍余量。
#define VT_MEMBER_TTL_MS 6000u
// 收到语音后,认为"某人正在发话"的持续时间。AUDIO_END 会提前结束。
#define VT_SPEAKER_HOLD_MS 700u

typedef struct {
    uint16_t sender;
    char name[VT_NAME_MAX_BYTES + 1];
    uint32_t last_seen_ms;
    bool used;
} vt_member_t;

typedef struct {
    vt_member_t members[VT_ROOM_MAX_MEMBERS];
    uint16_t self_id;
    uint16_t speaker_id;        // 0 = 当前无人发话
    uint32_t speaker_seen_ms;   // 最近一次收到该发话者语音的时刻
} vt_roster_t;

// self_id 是本机 sender(通常是开机随机生成的 16 位),自己不入表,
// UI 的"在线人数"= 表内人数 + 1(自己)。
void vt_roster_init(vt_roster_t *roster, uint16_t self_id);

// 清空成员表(换房间、断网时调用),保留 self_id。
void vt_roster_clear(vt_roster_t *roster);

// 登记或刷新一个成员。房间满员时返回 false(不挤掉最旧的:
// 先到先得更符合"讲一半不该被踢"的直觉)。
bool vt_roster_upsert(vt_roster_t *roster, uint16_t sender, const char *name,
                      uint32_t now_ms);

bool vt_roster_remove(vt_roster_t *roster, uint16_t sender);

// 剔除超过 TTL 的成员,返回被剔除的人数。
uint8_t vt_roster_expire(vt_roster_t *roster, uint32_t now_ms);

// 表内成员数(不含自己)。
uint8_t vt_roster_count(const vt_roster_t *roster);

// 含自己的房间人数,已按 VT_ROOM_MAX_MEMBERS 封顶。
uint8_t vt_roster_online(const vt_roster_t *roster);

// 查名字;查不到返回 NULL。空名字返回空串(UI 显示"<无名>")。
const char *vt_roster_name(const vt_roster_t *roster, uint16_t sender);

// 记一次"收到某人的语音"。
void vt_roster_note_audio(vt_roster_t *roster, uint16_t sender, uint32_t now_ms);

// 结束某人的发话(AUDIO_END 或本地停止发话)。
void vt_roster_end_audio(vt_roster_t *roster, uint16_t sender);

// 当前发话者:若超过 VT_SPEAKER_HOLD_MS 没再收到语音则视为结束,返回 0。
uint16_t vt_roster_speaker(const vt_roster_t *roster, uint32_t now_ms);

#ifdef __cplusplus
}
#endif

// main/app_ui.c —— 对讲机界面(第二版,整屏重做)。
//
// 设计取向:不做"卡片堆叠"的手机 App 感,而是像一台台式对讲机 ——
//   * 通栏排版:房号居中占主视觉,下面一条"链路色带"直接告诉用户
//     现在是走互联网中转还是局域网、通不通。
//   * 中间是真实的电平条:发话时取麦克风峰值,收听时取播放帧峰值,
//     电平来自 app_audio_level(),不是装饰动画。
//   * 底部整条是发话区,三态(空闲 / 我在发话 / 别人在发话)靠整块填色区分,
//     一眼能看出"现在能不能说"。
//   * 顶部只留电量、时间、一颗链路指示灯,不抢主视觉。
//
// 与基线 demo 的关系:本文件与 demo_* 无关,也没有复用 ui_pixel 的外壳,
// 页面、配色、排版都是按对讲场景重新画的三页(通话 / 成员 / 设置)。
//
// 字体约定:
//   * 中文一律显式指定 app_font_16(自生成的 Noto Sans SC 子集)。
//     默认 Montserrat 没有汉字,不显式指定就会显示成占位方框。
//   * 纯数字/英文用 Montserrat:房号 38 号、时间 20 号、电量 14 号。
//   * tests/test_app_font_coverage.py 会检查界面里出现的每个汉字都在
//     assets/fonts/app_font_symbols.txt 里,新增中文要跟着更新字库清单。
#include "app_ui.h"

#include "app_audio.h"
#include "app_config.h"
#include "app_protocol.h"
#include "app_state.h"
#include "app_storage.h"
#include "app_web.h"
#include "bsp_battery.h"
#include "bsp_display.h"

#include "esp_log.h"
#include "esp_system.h"
#include "lvgl.h"

#include <stdio.h>
#include <string.h>
#include <time.h>

LV_FONT_DECLARE(app_font_16);

static const char *TAG = "vt_ui";

// —— 配色 ——
#define C_BG        0x080B10u   // 底色(近黑,让琥珀色跳出来)
#define C_PANEL     0x121821u   // 面板/色带底
#define C_LINE      0x1F2833u   // 分隔线
#define C_ACCENT    0xFFB020u   // 琥珀:主强调(空闲/发话)
#define C_LIVE      0x2BB673u   // 绿:在线 / 收听中
#define C_ALERT     0xE5484Du   // 红:异常 / 不可用
#define C_INFO      0x4A9EFFu   // 蓝:网页配网
#define C_INK       0xF2F5F8u   // 主文字
#define C_INK_DIM   0x8B98A6u   // 次文字
#define C_TRACK     0x1B2330u   // 电平条底槽

// —— 版式(240 × 320)——
#define TOPBAR_H    30
#define FOOTER_H    22
#define CONTENT_Y   TOPBAR_H
#define CONTENT_H   (320 - TOPBAR_H - FOOTER_H)   // 268

// 通话页各行(屏幕绝对 y)
#define ROOM_CAP_Y  34
#define ROOM_NUM_Y  50
#define RIBBON_Y    102
#define METER_Y     140
#define METER_H     44
#define STATE_Y     190
#define INFO_Y      212
#define ME_Y        232
#define PTT_Y       252
#define PTT_H       44

// 电平条
#define METER_BARS  20u
#define METER_BAR_W 9u
#define METER_GAP   2u
// 20 根条共 20*9 + 19*2 = 218 px,左右各留 11 px 居中。
#define METER_X     11

typedef enum {
    ROW_BACK = 0,
    ROW_BRIGHTNESS,
    ROW_VOLUME,
    ROW_TRANSPORT,
    ROW_SERVER,
    ROW_SERVER_STATE,
    ROW_WEB,
    ROW_RESET,
    ROW_WIFI,
    ROW_IP,
    ROW_COUNT
} settings_row_t;

static lv_obj_t *s_scr;
static lv_obj_t *s_page_talk;
static lv_obj_t *s_page_members;
static lv_obj_t *s_page_settings;

// 顶部状态栏
static lv_obj_t *s_batt_fill;
static lv_obj_t *s_batt_label;
static lv_obj_t *s_time_label;
static lv_obj_t *s_link_led;
static lv_obj_t *s_footer;

// 通话页
static lv_obj_t *s_room_label;
static lv_obj_t *s_ribbon;
static lv_obj_t *s_ribbon_label;
static lv_obj_t *s_meter[METER_BARS];
static lv_obj_t *s_state_label;
static lv_obj_t *s_info_label;
static lv_obj_t *s_me_label;
static lv_obj_t *s_ptt;
static lv_obj_t *s_ptt_label;

// 成员页
#define MEMBER_ROWS 10
static lv_obj_t *s_member_rows[MEMBER_ROWS];

// 设置页
static lv_obj_t *s_set_rows[ROW_COUNT];
static lv_obj_t *s_set_values[ROW_COUNT];
static uint8_t s_sel;
static bool s_editing;
static bool s_reset_armed;
static uint8_t s_meter_level;

static vt_page_t s_page = VT_PAGE_TALK;
static lv_timer_t *s_timer;
static uint32_t s_last_battery_ms;
static bool s_web_hint_until_restart;

static uint32_t now_ms(void) {
    return (uint32_t)(lv_tick_get());
}

// —— 小工具 ——
static lv_obj_t *mk_label(lv_obj_t *parent, const char *text, const lv_font_t *font,
                          uint32_t color, lv_text_align_t align) {
    lv_obj_t *label = lv_label_create(parent);
    lv_obj_set_style_text_font(label, font, 0);
    lv_obj_set_style_text_color(label, lv_color_hex(color), 0);
    lv_label_set_text(label, text);
    lv_obj_set_style_text_align(label, align, 0);
    return label;
}

// —— 顶部状态栏 ——
static void build_topbar(lv_obj_t *parent) {
    lv_obj_t *bar = lv_obj_create(parent);
    lv_obj_set_size(bar, 240, TOPBAR_H);
    lv_obj_set_pos(bar, 0, 0);
    lv_obj_set_style_bg_color(bar, lv_color_hex(C_PANEL), 0);
    lv_obj_set_style_bg_opa(bar, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(bar, 0, 0);
    lv_obj_set_style_radius(bar, 0, 0);
    lv_obj_set_style_pad_all(bar, 0, 0);

    lv_obj_t *rule = lv_obj_create(bar);
    lv_obj_set_size(rule, 240, 1);
    lv_obj_set_pos(rule, 0, TOPBAR_H - 1);
    lv_obj_set_style_bg_color(rule, lv_color_hex(C_LINE), 0);
    lv_obj_set_style_bg_opa(rule, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(rule, 0, 0);

    // 左:电池槽 + 百分比
    lv_obj_t *batt = lv_obj_create(bar);
    lv_obj_set_size(batt, 24, 13);
    lv_obj_set_pos(batt, 8, 9);
    lv_obj_set_style_bg_opa(batt, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_color(batt, lv_color_hex(C_INK_DIM), 0);
    lv_obj_set_style_border_width(batt, 1, 0);
    lv_obj_set_style_radius(batt, 2, 0);
    lv_obj_set_style_pad_all(batt, 0, 0);

    s_batt_fill = lv_obj_create(batt);
    lv_obj_set_size(s_batt_fill, 20, 11);
    lv_obj_set_pos(s_batt_fill, 1, 0);
    lv_obj_set_style_bg_color(s_batt_fill, lv_color_hex(C_LIVE), 0);
    lv_obj_set_style_bg_opa(s_batt_fill, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(s_batt_fill, 0, 0);

    s_batt_label = mk_label(bar, "--", &lv_font_montserrat_14, C_INK, LV_TEXT_ALIGN_LEFT);
    lv_obj_set_pos(s_batt_label, 36, 8);

    // 中:时间
    s_time_label = mk_label(bar, "--:--", &lv_font_montserrat_20, C_INK, LV_TEXT_ALIGN_CENTER);
    lv_obj_set_size(s_time_label, 90, 24);
    lv_obj_set_pos(s_time_label, 75, 4);

    // 右:链路指示灯
    s_link_led = lv_obj_create(bar);
    lv_obj_set_size(s_link_led, 10, 10);
    lv_obj_set_pos(s_link_led, 222, 10);
    lv_obj_set_style_bg_color(s_link_led, lv_color_hex(C_ALERT), 0);
    lv_obj_set_style_bg_opa(s_link_led, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(s_link_led, 0, 0);
    lv_obj_set_style_radius(s_link_led, LV_RADIUS_CIRCLE, 0);
}

static void build_footer(lv_obj_t *parent) {
    s_footer = mk_label(parent, "按住 OK 发话    UP 设置    DOWN 成员",
                        &app_font_16, C_INK_DIM, LV_TEXT_ALIGN_CENTER);
    lv_obj_set_size(s_footer, 236, 18);
    lv_obj_set_pos(s_footer, 2, 320 - FOOTER_H + 2);
}

// —— 通话页 ——
static void build_talk_page(lv_obj_t *parent) {
    s_page_talk = lv_obj_create(parent);
    lv_obj_set_size(s_page_talk, 240, CONTENT_H);
    lv_obj_set_pos(s_page_talk, 0, CONTENT_Y);
    lv_obj_set_style_bg_opa(s_page_talk, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(s_page_talk, 0, 0);
    lv_obj_set_style_pad_all(s_page_talk, 0, 0);
    lv_obj_set_style_radius(s_page_talk, 0, 0);

    // 房号:全屏居中的主视觉
    lv_obj_t *cap = mk_label(s_page_talk, "房间号", &app_font_16, C_INK_DIM,
                             LV_TEXT_ALIGN_CENTER);
    lv_obj_set_size(cap, 240, 18);
    lv_obj_set_pos(cap, 0, ROOM_CAP_Y - CONTENT_Y);

    s_room_label = mk_label(s_page_talk, "000000", &lv_font_montserrat_38, C_ACCENT,
                            LV_TEXT_ALIGN_CENTER);
    lv_obj_set_size(s_room_label, 240, 46);
    lv_obj_set_pos(s_room_label, 0, ROOM_NUM_Y - CONTENT_Y);

    // 链路色带
    s_ribbon = lv_obj_create(s_page_talk);
    lv_obj_set_size(s_ribbon, 216, 26);
    lv_obj_set_pos(s_ribbon, 12, RIBBON_Y - CONTENT_Y);
    lv_obj_set_style_bg_color(s_ribbon, lv_color_hex(C_PANEL), 0);
    lv_obj_set_style_bg_opa(s_ribbon, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(s_ribbon, 0, 0);
    lv_obj_set_style_radius(s_ribbon, 13, 0);
    lv_obj_set_style_pad_all(s_ribbon, 0, 0);
    s_ribbon_label = mk_label(s_ribbon, "局域网 · 未连接", &app_font_16, C_INK_DIM,
                              LV_TEXT_ALIGN_CENTER);
    lv_obj_set_size(s_ribbon_label, 208, 18);
    lv_obj_set_pos(s_ribbon_label, 4, 4);

    // 电平条
    for (uint8_t i = 0; i < METER_BARS; i++) {
        lv_obj_t *bar = lv_bar_create(s_page_talk);
        lv_obj_set_size(bar, METER_BAR_W, METER_H);
        lv_obj_set_pos(bar, METER_X + (int)i * (METER_BAR_W + METER_GAP),
                       METER_Y - CONTENT_Y);
        lv_obj_set_style_bg_color(bar, lv_color_hex(C_TRACK), 0);
        lv_obj_set_style_bg_opa(bar, LV_OPA_COVER, 0);
        lv_obj_set_style_bg_color(bar, lv_color_hex(C_ACCENT), LV_PART_INDICATOR);
        lv_obj_set_style_border_width(bar, 0, 0);
        lv_obj_set_style_radius(bar, 1, 0);
        lv_obj_set_style_pad_all(bar, 0, 0);
        lv_bar_set_range(bar, 0, 100);
        lv_bar_set_value(bar, 0, LV_ANIM_OFF);
        s_meter[i] = bar;
    }

    // 状态字:空闲 / 我在发话 / 谁在发话
    s_state_label = mk_label(s_page_talk, "空闲", &app_font_16, C_INK_DIM,
                             LV_TEXT_ALIGN_CENTER);
    lv_obj_set_size(s_state_label, 236, 18);
    lv_obj_set_pos(s_state_label, 2, STATE_Y - CONTENT_Y);

    s_info_label = mk_label(s_page_talk, "在线 1 / 32 人", &app_font_16, C_INK,
                            LV_TEXT_ALIGN_LEFT);
    lv_obj_set_size(s_info_label, 216, 18);
    lv_obj_set_pos(s_info_label, 12, INFO_Y - CONTENT_Y);

    s_me_label = mk_label(s_page_talk, "我 · 未设置", &app_font_16, C_INK_DIM,
                          LV_TEXT_ALIGN_LEFT);
    lv_obj_set_size(s_me_label, 216, 18);
    lv_obj_set_pos(s_me_label, 12, ME_Y - CONTENT_Y);

    // 发话区
    s_ptt = lv_obj_create(s_page_talk);
    lv_obj_set_size(s_ptt, 216, PTT_H);
    lv_obj_set_pos(s_ptt, 12, PTT_Y - CONTENT_Y);
    lv_obj_set_style_bg_color(s_ptt, lv_color_hex(C_PANEL), 0);
    lv_obj_set_style_bg_opa(s_ptt, LV_OPA_COVER, 0);
    lv_obj_set_style_border_color(s_ptt, lv_color_hex(C_ACCENT), 0);
    lv_obj_set_style_border_width(s_ptt, 2, 0);
    lv_obj_set_style_radius(s_ptt, 8, 0);
    lv_obj_set_style_pad_all(s_ptt, 0, 0);

    s_ptt_label = mk_label(s_ptt, "按住 OK 发话", &app_font_16, C_ACCENT,
                           LV_TEXT_ALIGN_CENTER);
    lv_obj_set_size(s_ptt_label, 204, 20);
    lv_obj_set_pos(s_ptt_label, 6, 12);
}

// —— 成员页 ——
static void build_members_page(lv_obj_t *parent) {
    s_page_members = lv_obj_create(parent);
    lv_obj_set_size(s_page_members, 240, CONTENT_H);
    lv_obj_set_pos(s_page_members, 0, CONTENT_Y);
    lv_obj_set_style_bg_opa(s_page_members, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(s_page_members, 0, 0);
    lv_obj_set_style_pad_all(s_page_members, 0, 0);
    lv_obj_set_style_radius(s_page_members, 0, 0);
    lv_obj_add_flag(s_page_members, LV_OBJ_FLAG_HIDDEN);

    lv_obj_t *cap = mk_label(s_page_members, "房间成员(第一行是自己)", &app_font_16,
                             C_INK_DIM, LV_TEXT_ALIGN_LEFT);
    lv_obj_set_size(cap, 216, 18);
    lv_obj_set_pos(cap, 12, 4);

    for (int i = 0; i < MEMBER_ROWS; i++) {
        s_member_rows[i] = mk_label(s_page_members, "", &app_font_16, C_INK,
                                    LV_TEXT_ALIGN_LEFT);
        lv_obj_set_size(s_member_rows[i], 216, 22);
        lv_label_set_long_mode(s_member_rows[i], LV_LABEL_LONG_DOT);
        lv_obj_set_pos(s_member_rows[i], 12, 26 + i * 24);
    }
}

// —— 设置页 ——
static const char *SETTINGS_TITLES[ROW_COUNT] = {
    "返回通话",
    "屏幕亮度",
    "设备音量",
    "传输方式",
    "中转服务器",
    "服务器状态",
    "打开网页设置",
    "还原固件初始值",
    "当前 Wi-Fi",
    "当前 IP",
};

static void build_settings_page(lv_obj_t *parent) {
    s_page_settings = lv_obj_create(parent);
    lv_obj_set_size(s_page_settings, 240, CONTENT_H);
    lv_obj_set_pos(s_page_settings, 0, CONTENT_Y);
    lv_obj_set_style_bg_opa(s_page_settings, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(s_page_settings, 0, 0);
    lv_obj_set_style_pad_all(s_page_settings, 0, 0);
    lv_obj_set_style_radius(s_page_settings, 0, 0);
    // 行数比内容区高一点,允许上下滚动,免得小屏裁掉最后一行。
    lv_obj_set_scroll_dir(s_page_settings, LV_DIR_VER);
    lv_obj_set_scrollbar_mode(s_page_settings, LV_SCROLLBAR_MODE_AUTO);
    lv_obj_add_flag(s_page_settings, LV_OBJ_FLAG_HIDDEN);

    for (int i = 0; i < ROW_COUNT; i++) {
        lv_obj_t *row = lv_obj_create(s_page_settings);
        lv_obj_set_size(row, 216, 24);
        lv_obj_set_pos(row, 12, 4 + i * 26);
        lv_obj_set_style_bg_color(row, lv_color_hex(C_PANEL), 0);
        lv_obj_set_style_bg_opa(row, LV_OPA_COVER, 0);
        lv_obj_set_style_border_color(row, lv_color_hex(C_LINE), 0);
        lv_obj_set_style_border_width(row, 1, 0);
        lv_obj_set_style_radius(row, 3, 0);
        lv_obj_set_style_pad_all(row, 0, 0);
        s_set_rows[i] = row;

        lv_obj_t *title = mk_label(row, SETTINGS_TITLES[i], &app_font_16, C_INK,
                                   LV_TEXT_ALIGN_LEFT);
        lv_obj_set_size(title, 108, 18);
        lv_label_set_long_mode(title, LV_LABEL_LONG_DOT);
        lv_obj_set_pos(title, 8, 3);

        s_set_values[i] = mk_label(row, "", &app_font_16, C_INK_DIM, LV_TEXT_ALIGN_RIGHT);
        lv_obj_set_size(s_set_values[i], 94, 18);
        lv_label_set_long_mode(s_set_values[i], LV_LABEL_LONG_DOT);
        lv_obj_set_pos(s_set_values[i], 114, 3);
    }
}

// —— 刷新 ——
static void refresh_topbar(void) {
    app_state_lock();
    vt_link_state_t link = app_state()->link;
    bool ap_on = app_state()->ap_on;
    int soc = app_state()->battery_soc;
    app_state_unlock();

    // 电量:读不到时显示 -- 并清空电池槽,不编一个数字出来。
    if (soc < 0) {
        lv_label_set_text(s_batt_label, "--");
        lv_obj_set_width(s_batt_fill, 0);
        lv_obj_set_style_bg_color(s_batt_fill, lv_color_hex(C_INK_DIM), 0);
    } else {
        char text[12];
        snprintf(text, sizeof(text), "%d%%", soc);
        lv_label_set_text(s_batt_label, text);
        int inner = 20 * soc / 100;
        if (inner < 2) inner = 2;
        lv_obj_set_width(s_batt_fill, inner);
        lv_obj_set_style_bg_color(
            s_batt_fill,
            lv_color_hex(soc <= 15 ? C_ALERT : (soc <= 30 ? C_ACCENT : C_LIVE)), 0);
    }

    time_t t = time(NULL);
    if (t > 1700000000) {
        struct tm tm_now;
        localtime_r(&t, &tm_now);
        char text[8];
        snprintf(text, sizeof(text), "%02d:%02d", tm_now.tm_hour, tm_now.tm_min);
        lv_label_set_text(s_time_label, text);
        app_state_lock();
        app_state()->time_valid = true;
        app_state_unlock();
    } else {
        lv_label_set_text(s_time_label, "--:--");
    }

    // 指示灯:网页热点优先(用户正连着它配网),其次链路状态。
    uint32_t color = C_ALERT;
    bool blink = true;
    if (ap_on && s_web_hint_until_restart) {
        color = C_INFO;
        blink = false;
    } else if (link == VT_LINK_UP) {
        color = C_LIVE;
        blink = false;
    } else if (link == VT_LINK_CONNECTING) {
        color = C_ACCENT;
    }
    lv_obj_set_style_bg_color(s_link_led, lv_color_hex(color), 0);
    lv_obj_set_style_bg_opa(s_link_led,
        blink ? ((now_ms() % 1000u) < 500u ? LV_OPA_COVER : LV_OPA_30) : LV_OPA_COVER, 0);
}

// 链路色带:把"走哪条路 + 通不通"压成一句话。
static void refresh_ribbon(uint8_t transport, vt_link_state_t link,
                           vt_server_state_t server) {
    const char *text;
    uint32_t color;

    if (transport == (uint8_t)VT_TRANSPORT_SERVER && server != VT_SERVER_NONE) {
        switch (server) {
            case VT_SERVER_ONLINE:
                text = "互联网中转 · 已连服务器"; color = C_LIVE;   break;
            case VT_SERVER_FAILED:
                text = "中转地址解析失败 · 暂用局域网"; color = C_ALERT; break;
            case VT_SERVER_SEEKING:
            default:
                text = "互联网中转 · 寻找服务器"; color = C_ACCENT; break;
        }
    } else if (transport == (uint8_t)VT_TRANSPORT_SERVER) {
        // 选了互联网模式但没填地址:行为就是局域网,别让人以为在等服务器。
        text = "局域网 · 未填服务器地址"; color = C_INK_DIM;
    } else if (link == VT_LINK_UP) {
        text = "局域网 · 已连接"; color = C_LIVE;
    } else if (link == VT_LINK_CONNECTING) {
        text = "局域网 · 连接中"; color = C_ACCENT;
    } else {
        text = "局域网 · 未连接"; color = C_ALERT;
    }

    // 色带底固定用面板色,只让文字与描边跟着状态变 —— 半透明叠色在
    // 深色底上容易糊成一片,描边更清楚也更好做对比度。
    lv_label_set_text(s_ribbon_label, text);
    lv_obj_set_style_bg_color(s_ribbon, lv_color_hex(C_PANEL), 0);
    lv_obj_set_style_bg_opa(s_ribbon, LV_OPA_COVER, 0);
    lv_obj_set_style_border_color(s_ribbon, lv_color_hex(color), 0);
    lv_obj_set_style_border_width(s_ribbon, 1, 0);
    lv_obj_set_style_text_color(s_ribbon_label, lv_color_hex(color), 0);
}

static void refresh_meter(bool talking, bool listening, uint8_t level) {
    // 电平条只是"有没有声音在走"的指示:上升跟手,下降慢一点好看清。
    if (level > s_meter_level) s_meter_level = level;
    else s_meter_level = (s_meter_level > 8u) ? (uint8_t)(s_meter_level - 8u) : 0u;
    if (!talking && !listening) s_meter_level = 0u;

    uint32_t color = talking ? C_ACCENT : C_LIVE;
    uint32_t filled = ((uint32_t)s_meter_level * METER_BARS + 99u) / 100u;
    for (uint8_t i = 0; i < METER_BARS; i++) {
        lv_obj_set_style_bg_color(s_meter[i], lv_color_hex(color), LV_PART_INDICATOR);
        lv_bar_set_value(s_meter[i], (i < filled) ? 100 : 0, LV_ANIM_OFF);
    }
}

static void refresh_talk(void) {
    app_state_lock();
    uint32_t room = app_state()->cfg.room;
    uint8_t online = app_state()->online;
    bool talking = app_state()->talking;
    uint16_t speaker = app_state()->speaker_id;
    char name[VT_NAME_MAX_BYTES + 1];
    strncpy(name, app_state()->cfg.name, sizeof(name));
    name[VT_NAME_MAX_BYTES] = '\0';
    char speaker_name[VT_NAME_MAX_BYTES + 1];
    const char *found = vt_roster_name(&app_state()->roster, speaker);
    strncpy(speaker_name, found ? found : "", sizeof(speaker_name));
    speaker_name[VT_NAME_MAX_BYTES] = '\0';
    vt_link_state_t link = app_state()->link;
    uint8_t transport = app_state()->cfg.transport;
    vt_server_state_t server = app_state()->server_state;
    app_state_unlock();

    char room_text[8];
    vt_format_room(room, room_text);
    lv_label_set_text(s_room_label, room_text);

    refresh_ribbon(transport, link, server);

    char info[24];
    snprintf(info, sizeof(info), "在线 %u / %u 人",
             (unsigned)online, (unsigned)VT_ROOM_MAX_MEMBERS);
    lv_label_set_text(s_info_label, info);

    char me[40];
    snprintf(me, sizeof(me), "我 · %s", name[0] ? name : "未设置");
    lv_label_set_text(s_me_label, me);

    bool listening = (!talking && speaker != 0u);
    refresh_meter(talking, listening, app_audio_level());

    // 发话区三态
    if (talking) {
        lv_obj_set_style_bg_color(s_ptt, lv_color_hex(C_ACCENT), 0);
        lv_obj_set_style_border_color(s_ptt, lv_color_hex(C_ACCENT), 0);
        lv_obj_set_style_text_color(s_ptt_label, lv_color_hex(C_BG), 0);
        lv_label_set_text(s_ptt_label, "发话中 · 松开结束");
        lv_label_set_text(s_state_label, "我在发话");
        lv_obj_set_style_text_color(s_state_label, lv_color_hex(C_ACCENT), 0);
    } else if (listening) {
        lv_obj_set_style_bg_color(s_ptt, lv_color_hex(C_PANEL), 0);
        lv_obj_set_style_border_color(s_ptt, lv_color_hex(C_LIVE), 0);
        lv_obj_set_style_text_color(s_ptt_label, lv_color_hex(C_LIVE), 0);
        lv_label_set_text(s_ptt_label, "收听中 · 请等待");
        char text[48];
        snprintf(text, sizeof(text), "%s 正在发话",
                 speaker_name[0] ? speaker_name : "未知成员");
        lv_label_set_text(s_state_label, text);
        lv_obj_set_style_text_color(s_state_label, lv_color_hex(C_LIVE), 0);
    } else {
        lv_obj_set_style_bg_color(s_ptt, lv_color_hex(C_PANEL), 0);
        lv_obj_set_style_border_color(s_ptt, lv_color_hex(C_ACCENT), 0);
        lv_obj_set_style_text_color(s_ptt_label, lv_color_hex(C_ACCENT), 0);
        lv_label_set_text(s_ptt_label, "按住 OK 发话");
        lv_label_set_text(s_state_label, "空闲 · 可发话");
        lv_obj_set_style_text_color(s_state_label, lv_color_hex(C_INK_DIM), 0);
    }
}

static void refresh_members(void) {
    app_state_lock();
    char self_name[VT_NAME_MAX_BYTES + 1];
    strncpy(self_name, app_state()->cfg.name, sizeof(self_name));
    self_name[VT_NAME_MAX_BYTES] = '\0';
    vt_member_t copy[VT_ROOM_MAX_MEMBERS];
    memcpy(copy, app_state()->roster.members, sizeof(copy));
    uint16_t speaker = app_state()->speaker_id;
    app_state_unlock();

    char line[48];
    snprintf(line, sizeof(line), "1. %s(我)", self_name[0] ? self_name : "未设置");
    lv_label_set_text(s_member_rows[0], line);
    lv_obj_set_style_text_color(s_member_rows[0], lv_color_hex(C_ACCENT), 0);

    int row = 1;
    for (size_t i = 0; i < VT_ROOM_MAX_MEMBERS && row < MEMBER_ROWS; i++) {
        if (!copy[i].used) continue;
        const char *mark = (copy[i].sender == speaker) ? " 发话中" : "";
        snprintf(line, sizeof(line), "%d. %s%s", row + 1,
                 copy[i].name[0] ? copy[i].name : "无名", mark);
        lv_label_set_text(s_member_rows[row], line);
        lv_obj_set_style_text_color(s_member_rows[row],
            lv_color_hex(copy[i].sender == speaker ? C_LIVE : C_INK), 0);
        row++;
    }
    for (int i = row; i < MEMBER_ROWS; i++) {
        lv_label_set_text(s_member_rows[i], "");
    }
}

// 服务器状态的一句话说明(设置页与网页共用同一套措辞)。
static const char *server_state_text(vt_server_state_t state, uint8_t transport) {
    if (transport != (uint8_t)VT_TRANSPORT_SERVER) return "未使用(局域网模式)";
    switch (state) {
        case VT_SERVER_ONLINE:  return "在线";
        case VT_SERVER_SEEKING: return "寻找中";
        case VT_SERVER_FAILED:  return "地址解析失败(已退回局域网)";
        case VT_SERVER_NONE:
        default:                return "未配置(局域网自动发现)";
    }
}

static void refresh_settings(void) {
    app_state_lock();
    vt_config_t cfg = app_state()->cfg;
    vt_server_state_t server = app_state()->server_state;
    char ssid[33];
    strncpy(ssid, app_state()->ssid, sizeof(ssid));
    ssid[32] = '\0';
    char ip[16];
    strncpy(ip, app_state()->ip, sizeof(ip));
    ip[15] = '\0';
    app_state_unlock();

    char server_value[VT_SERVER_HOST_MAX + 8];
    if (cfg.server_host[0]) {
        snprintf(server_value, sizeof(server_value), "%s:%u",
                 cfg.server_host, (unsigned)cfg.server_port);
    } else {
        snprintf(server_value, sizeof(server_value), "未设置");
    }

    lv_label_set_text(s_set_values[ROW_BACK], "");
    lv_label_set_text_fmt(s_set_values[ROW_BRIGHTNESS], "%u%%", (unsigned)cfg.brightness);
    lv_label_set_text_fmt(s_set_values[ROW_VOLUME], "%u%%", (unsigned)cfg.volume);
    lv_label_set_text(s_set_values[ROW_TRANSPORT],
                      cfg.transport == (uint8_t)VT_TRANSPORT_SERVER ? "互联网中转" : "局域网");
    lv_label_set_text(s_set_values[ROW_SERVER], server_value);
    lv_label_set_text(s_set_values[ROW_SERVER_STATE], server_state_text(server, cfg.transport));
    lv_label_set_text(s_set_values[ROW_WEB], app_web_running() ? "已开启" : "");
    lv_label_set_text(s_set_values[ROW_RESET], s_reset_armed ? "再按 OK 确认" : "");
    lv_label_set_text(s_set_values[ROW_WIFI], ssid[0] ? ssid : "未连接");
    lv_label_set_text(s_set_values[ROW_IP], ip[0] ? ip : "无");

    for (int i = 0; i < ROW_COUNT; i++) {
        bool selected = ((uint8_t)i == s_sel);
        lv_obj_set_style_border_color(
            s_set_rows[i],
            lv_color_hex(selected ? (s_editing ? C_LIVE : C_ACCENT) : C_LINE), 0);
        lv_obj_set_style_border_width(s_set_rows[i], selected ? 2 : 1, 0);
        lv_obj_set_style_text_color(
            lv_obj_get_child(s_set_rows[i], 0),
            lv_color_hex(selected ? C_ACCENT : C_INK), 0);
    }
}

static void refresh_footer(void) {
    const char *text;
    if (s_page == VT_PAGE_TALK) {
        text = "按住 OK 发话    UP 设置    DOWN 成员";
    } else if (s_page == VT_PAGE_MEMBERS) {
        text = "短按任意键返回通话";
    } else if (s_editing) {
        text = "UP/DOWN 改值    OK 保存";
    } else {
        text = "UP/DOWN 选择    OK 确认    第一行返回";
    }
    if (s_page == VT_PAGE_SETTINGS && s_web_hint_until_restart && app_web_running()) {
        text = "手机连热点 VoiceTalk-XXXX,浏览器打开 http://192.168.4.1";
    }
    lv_label_set_text(s_footer, text);
}

static void refresh_timer(lv_timer_t *timer) {
    (void)timer;
    // 电量要读一次 I2C,不必每个刷新周期都读。
    if (now_ms() - s_last_battery_ms > 5000u) {
        s_last_battery_ms = now_ms();
        app_state_lock();
        app_state()->battery_soc = bsp_battery_soc();
        app_state_unlock();
    }
    refresh_topbar();
    if (s_page == VT_PAGE_TALK) refresh_talk();
    else if (s_page == VT_PAGE_MEMBERS) refresh_members();
    else refresh_settings();
    refresh_footer();
}

// —— 页面切换 ——
static void show_page(vt_page_t page) {
    s_page = page;
    lv_obj_add_flag(s_page_talk, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(s_page_members, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(s_page_settings, LV_OBJ_FLAG_HIDDEN);
    if (page == VT_PAGE_TALK) lv_obj_remove_flag(s_page_talk, LV_OBJ_FLAG_HIDDEN);
    else if (page == VT_PAGE_MEMBERS) lv_obj_remove_flag(s_page_members, LV_OBJ_FLAG_HIDDEN);
    else lv_obj_remove_flag(s_page_settings, LV_OBJ_FLAG_HIDDEN);
    s_editing = false;
    s_reset_armed = false;
    // 换页时把选中行滚回视野:设置页比内容区高,可能停在下面。
    if (page == VT_PAGE_SETTINGS) {
        lv_obj_scroll_to_y(s_page_settings, 0, LV_ANIM_OFF);
    }
}

void app_ui_show_talk(void) {
    show_page(VT_PAGE_TALK);
}

vt_page_t app_ui_page(void) {
    return s_page;
}

// —— 设置项动作 ——
static void settings_apply(void) {
    app_state_lock();
    vt_config_t cfg = app_state()->cfg;
    app_state_unlock();
    app_storage_save(&cfg);
}

static void settings_adjust(int delta) {
    app_state_lock();
    vt_config_t *cfg = &app_state()->cfg;
    if (s_sel == ROW_BRIGHTNESS) {
        int value = (int)cfg->brightness + delta * 10;
        if (value < (int)VT_BRIGHTNESS_MIN) value = (int)VT_BRIGHTNESS_MIN;
        if (value > (int)VT_BRIGHTNESS_MAX) value = (int)VT_BRIGHTNESS_MAX;
        cfg->brightness = (uint8_t)value;
    } else if (s_sel == ROW_VOLUME) {
        int value = (int)cfg->volume + delta * 5;
        if (value < (int)VT_VOLUME_MIN) value = (int)VT_VOLUME_MIN;
        if (value > (int)VT_VOLUME_MAX) value = (int)VT_VOLUME_MAX;
        cfg->volume = (uint8_t)value;
    }
    app_state_unlock();

    if (s_sel == ROW_BRIGHTNESS) {
        app_state_lock();
        uint8_t brightness = app_state()->cfg.brightness;
        app_state_unlock();
        bsp_display_backlight(brightness);
    } else if (s_sel == ROW_VOLUME) {
        app_state_lock();
        uint8_t volume = app_state()->cfg.volume;
        app_state_unlock();
        app_audio_set_volume(volume);
    }
}

static void settings_activate(void) {
    if (s_sel == ROW_BACK) {
        show_page(VT_PAGE_TALK);
        return;
    }
    if (s_sel == ROW_BRIGHTNESS || s_sel == ROW_VOLUME) {
        s_editing = !s_editing;
        if (!s_editing) settings_apply();
        return;
    }
    if (s_sel == ROW_TRANSPORT) {
        app_state_lock();
        vt_config_t *cfg = &app_state()->cfg;
        cfg->transport = (cfg->transport == (uint8_t)VT_TRANSPORT_SERVER)
                       ? (uint8_t)VT_TRANSPORT_LAN
                       : (uint8_t)VT_TRANSPORT_SERVER;
        app_state_unlock();
        settings_apply();
        return;
    }
    if (s_sel == ROW_WEB) {
        if (app_web_start() == ESP_OK) {
            s_web_hint_until_restart = true;
            ESP_LOGI(TAG, "网页设置已开启: 1) 手机连接 VoiceTalk 热点 2) 浏览器打开 http://%s",
                     app_web_ap_ip());
        }
        return;
    }
    if (s_sel == ROW_RESET) {
        if (!s_reset_armed) {
            s_reset_armed = true;      // 二次确认,避免误触清掉配置
            return;
        }
        ESP_LOGW(TAG, "还原固件初始值并重启");
        app_storage_reset();
        esp_restart();
        return;
    }
    // ROW_SERVER / ROW_SERVER_STATE / ROW_WIFI / ROW_IP 是只读信息。
    // 服务器地址只能在网页里改(要输域名/端口,三个按键敲不进去)。
}

bool app_ui_handle_key(bsp_btn_t btn, bsp_btn_ev_t ev) {
    if (s_page == VT_PAGE_TALK) {
        // PTT 由 main.c 直接切音频,这里只负责翻页。
        if (btn == BSP_BTN_OK && (ev == BSP_BTN_PRESS || ev == BSP_BTN_RELEASE)) {
            return false;
        }
        if (ev != BSP_BTN_CLICK) return false;
        if (btn == BSP_BTN_UP) { show_page(VT_PAGE_SETTINGS); return true; }
        if (btn == BSP_BTN_DOWN) { show_page(VT_PAGE_MEMBERS); return true; }
        return false;
    }

    if (s_page == VT_PAGE_MEMBERS) {
        if (ev == BSP_BTN_CLICK) { show_page(VT_PAGE_TALK); return true; }
        return false;
    }

    // 设置页:长按不用于返回,也不做任何事。
    if (ev != BSP_BTN_CLICK) return false;
    if (s_editing && (btn == BSP_BTN_UP || btn == BSP_BTN_DOWN)) {
        settings_adjust(btn == BSP_BTN_UP ? 1 : -1);
        return true;
    }
    if (btn == BSP_BTN_UP) {
        s_sel = (uint8_t)((s_sel == 0u) ? (ROW_COUNT - 1) : (s_sel - 1u));
        s_reset_armed = false;
        return true;
    }
    if (btn == BSP_BTN_DOWN) {
        s_sel = (uint8_t)((s_sel + 1u) % ROW_COUNT);
        s_reset_armed = false;
        return true;
    }
    if (btn == BSP_BTN_OK) {
        settings_activate();
        return true;
    }
    return false;
}

esp_err_t app_ui_init(void) {
    s_scr = lv_obj_create(NULL);
    lv_obj_set_style_bg_color(s_scr, lv_color_hex(C_BG), 0);
    lv_obj_set_style_bg_opa(s_scr, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(s_scr, 0, 0);
    lv_obj_set_style_radius(s_scr, 0, 0);
    lv_obj_set_style_pad_all(s_scr, 0, 0);

    build_topbar(s_scr);
    build_talk_page(s_scr);
    build_members_page(s_scr);
    build_settings_page(s_scr);
    build_footer(s_scr);

    show_page(VT_PAGE_TALK);
    lv_screen_load(s_scr);

    if (!s_timer) s_timer = lv_timer_create(refresh_timer, 200, NULL);
    refresh_timer(NULL);
    return ESP_OK;
}

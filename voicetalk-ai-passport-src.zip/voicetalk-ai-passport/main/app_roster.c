// main/app_roster.c —— app_roster.h 的实现。
#include "app_roster.h"

#include <string.h>

void vt_roster_init(vt_roster_t *roster, uint16_t self_id) {
    if (!roster) return;
    memset(roster, 0, sizeof(*roster));
    roster->self_id = self_id;
}

void vt_roster_clear(vt_roster_t *roster) {
    if (!roster) return;
    uint16_t self_id = roster->self_id;
    memset(roster, 0, sizeof(*roster));
    roster->self_id = self_id;
}

bool vt_roster_upsert(vt_roster_t *roster, uint16_t sender, const char *name,
                      uint32_t now_ms) {
    if (!roster || !name) return false;
    if (sender == 0u || sender == roster->self_id) return false;  // 自己不入表

    for (size_t i = 0; i < VT_ROOM_MAX_MEMBERS; i++) {
        if (roster->members[i].used && roster->members[i].sender == sender) {
            roster->members[i].last_seen_ms = now_ms;
            strncpy(roster->members[i].name, name, VT_NAME_MAX_BYTES);
            roster->members[i].name[VT_NAME_MAX_BYTES] = '\0';
            return true;
        }
    }
    for (size_t i = 0; i < VT_ROOM_MAX_MEMBERS; i++) {
        if (!roster->members[i].used) {
            roster->members[i].used = true;
            roster->members[i].sender = sender;
            roster->members[i].last_seen_ms = now_ms;
            strncpy(roster->members[i].name, name, VT_NAME_MAX_BYTES);
            roster->members[i].name[VT_NAME_MAX_BYTES] = '\0';
            return true;
        }
    }
    return false;  // 满员
}

bool vt_roster_remove(vt_roster_t *roster, uint16_t sender) {
    if (!roster) return false;
    for (size_t i = 0; i < VT_ROOM_MAX_MEMBERS; i++) {
        if (roster->members[i].used && roster->members[i].sender == sender) {
            roster->members[i].used = false;
            roster->members[i].name[0] = '\0';
            if (roster->speaker_id == sender) roster->speaker_id = 0;
            return true;
        }
    }
    return false;
}

uint8_t vt_roster_expire(vt_roster_t *roster, uint32_t now_ms) {
    if (!roster) return 0;
    uint8_t removed = 0;
    for (size_t i = 0; i < VT_ROOM_MAX_MEMBERS; i++) {
        if (!roster->members[i].used) continue;
        // 用无符号差处理 32 位回绕。
        uint32_t age = now_ms - roster->members[i].last_seen_ms;
        if (age > VT_MEMBER_TTL_MS) {
            roster->members[i].used = false;
            roster->members[i].name[0] = '\0';
            if (roster->speaker_id == roster->members[i].sender) roster->speaker_id = 0;
            removed++;
        }
    }
    return removed;
}

uint8_t vt_roster_count(const vt_roster_t *roster) {
    if (!roster) return 0;
    uint8_t n = 0;
    for (size_t i = 0; i < VT_ROOM_MAX_MEMBERS; i++) {
        if (roster->members[i].used) n++;
    }
    return n;
}

uint8_t vt_roster_online(const vt_roster_t *roster) {
    uint8_t n = vt_roster_count(roster);
    if (n >= VT_ROOM_MAX_MEMBERS) return VT_ROOM_MAX_MEMBERS;
    return (uint8_t)(n + 1u);  // 加上自己
}

const char *vt_roster_name(const vt_roster_t *roster, uint16_t sender) {
    if (!roster) return NULL;
    for (size_t i = 0; i < VT_ROOM_MAX_MEMBERS; i++) {
        if (roster->members[i].used && roster->members[i].sender == sender) {
            return roster->members[i].name;
        }
    }
    return NULL;
}

void vt_roster_note_audio(vt_roster_t *roster, uint16_t sender, uint32_t now_ms) {
    if (!roster || sender == 0u || sender == roster->self_id) return;
    roster->speaker_id = sender;
    roster->speaker_seen_ms = now_ms;
}

void vt_roster_end_audio(vt_roster_t *roster, uint16_t sender) {
    if (!roster) return;
    if (roster->speaker_id == sender) roster->speaker_id = 0;
}

uint16_t vt_roster_speaker(const vt_roster_t *roster, uint32_t now_ms) {
    if (!roster || roster->speaker_id == 0u) return 0u;
    uint32_t age = now_ms - roster->speaker_seen_ms;
    if (age > VT_SPEAKER_HOLD_MS) return 0u;  // 不改写状态,让下一次查询仍可能恢复
    return roster->speaker_id;
}

// main/app_net.h —— Wi-Fi 连接、UDP 线路、中转服务器发现、NTP 校时。
//
// 传输方式:
//   * VT_TRANSPORT_LAN    :UDP 发到本网段广播地址,同一个 Wi-Fi 下直接互通。
//   * VT_TRANSPORT_SERVER :中转服务器,两条路自动选:
//       1) 网页填了服务器地址(域名或 IP)→ DNS 解析后单播过去,可跨公网;
//       2) 没填(或解析不出来)→ UDP 广播找局域网里的 voice_relay_server.py,
//          找到后单播发给它。
//     由它转发给同房间的其他人。服务器地址在网页设置页填写,不是写死的。
#pragma once

#include "app_config.h"
#include "app_protocol.h"

#include "esp_err.h"

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define VT_UDP_PORT 8801u

// 启动网络栈:初始化 netif/Wi-Fi(STA + 用于网页设置的 AP)、建 UDP 套接字、
// 起网络任务。重复调用返回 ESP_OK。
esp_err_t app_net_start(void);

// 重新按配置里的 Wi-Fi 列表连接(网页保存了新 Wi-Fi 后调用)。
esp_err_t app_net_reconnect(void);

// 网页热点是否已开。
bool app_net_ap_enabled(void);

// 发送一帧语音。len 必须 <= VT_AUDIO_FRAME_BYTES。
void app_net_send_audio(const uint8_t *pcm, uint16_t len);

// 结束一次发话:通知对端立刻停止播放。
void app_net_send_audio_end(void);

// 立即广播一次上线(改名/换房后马上让同伴看到)。
void app_net_send_hello_now(void);

// 同步一次时间(连上 Wi-Fi 后自动调用,也可手动触发)。
void app_net_sync_time(void);

// 重启/关机前广播一次下线,让同伴立刻把自己从名单里摘掉。
void app_net_shutdown(void);

#ifdef __cplusplus
}
#endif

// main/app_state.c —— 运行时状态单例 + 互斥锁。
#include "app_state.h"

#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

static app_state_t s_state;
static SemaphoreHandle_t s_mutex;

void app_state_init(void) {
    s_mutex = xSemaphoreCreateRecursiveMutex();
    app_state_lock();
    app_state_t *st = &s_state;
    st->self_id = 0;
    st->link = VT_LINK_DOWN;
    st->ssid[0] = '\0';
    st->ip[0] = '\0';
    st->rssi = 0;
    st->ap_on = false;
    st->relay_seen = false;
    st->relay_addr = 0;
    st->relay_port = 0;
    st->talking = false;
    st->speaker_id = 0;
    st->online = 1;
    st->battery_soc = -1;
    st->time_valid = false;
    vt_roster_init(&st->roster, 0);
    app_state_unlock();
}

app_state_t *app_state(void) {
    return &s_state;
}

void app_state_lock(void) {
    if (s_mutex) xSemaphoreTakeRecursive(s_mutex, portMAX_DELAY);
}

void app_state_unlock(void) {
    if (s_mutex) xSemaphoreGiveRecursive(s_mutex);
}

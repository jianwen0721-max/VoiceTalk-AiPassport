// main/app_config.h —— VoiceTalk 对讲机的持久化配置:结构、默认值与校验。
//
// 本文件只做"值"层面的事(默认值、范围钳制、Wi-Fi 列表增删),不碰 NVS,
// 因此可以在主机上直接单测;真正的 Flash 读写在 app_storage.c。
#pragma once

#include "app_protocol.h"

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// 保存的 Wi-Fi 凭据条数上限(网页里可以增删)。
#define VT_WIFI_MAX 5u
#define VT_WIFI_SSID_MAX 32u   // 不含 '\0'(Wi-Fi 标准最长 32)
#define VT_WIFI_PASS_MAX 64u   // WPA2 最长 63 + '\0'

// 互联网中转服务器。
// 留空 = 不指定服务器,设备退回局域网广播发现(与加这个字段之前的行为一致),
// 所以旧配置升级上来行为不变;填了域名或 IP 才会跨公网。
// 64 字节够放常见 DDNS 域名(如 voice.example.com),也够放 IPv4 字面量。
#define VT_SERVER_HOST_MAX 64u        // 不含 '\0'
#define VT_SERVER_PORT_DEFAULT 8801u
#define VT_SERVER_PORT_MIN 1u
#define VT_SERVER_PORT_MAX 65535u

// 传输方式
typedef enum {
    VT_TRANSPORT_LAN = 0,     // 局域网广播(同一网段直接互通,不需要服务器)
    VT_TRANSPORT_SERVER = 1,  // 服务器中转:优先用网页填的地址(可跨公网),
                              // 没填或解析不出来时自动退回局域网广播发现
} vt_transport_t;

// 屏幕亮度下限:10% —— 全黑会让用户以为设备坏了。
#define VT_BRIGHTNESS_MIN 10u
#define VT_BRIGHTNESS_MAX 100u
#define VT_VOLUME_MIN 0u
#define VT_VOLUME_MAX 100u

typedef struct {
    char ssid[VT_WIFI_SSID_MAX + 1];
    char pass[VT_WIFI_PASS_MAX + 1];
} vt_wifi_entry_t;

typedef struct {
    char name[VT_NAME_MAX_BYTES + 1];  // 使用者名称(UTF-8:英文/数字/汉字)
    uint32_t room;                     // 6 位房间号
    uint16_t passcode;                 // 4 位房间密码
    bool has_pass;                     // false = 开放房间
    uint8_t volume;                    // 设备音量 0..100
    uint8_t brightness;                // 屏幕亮度 10..100
    uint8_t transport;                 // vt_transport_t
    vt_wifi_entry_t wifi[VT_WIFI_MAX];
    uint8_t wifi_count;

    char server_host[VT_SERVER_HOST_MAX + 1];  // 空串 = 不指定服务器
    uint16_t server_port;                      // 0/越界 → VT_SERVER_PORT_DEFAULT
} vt_config_t;

// 出厂默认值。用户名留空 —— 首次开机时由 UI 提示"请用网页设置名称",
// 而不是拿一个占位名字冒充用户。
void vt_config_defaults(vt_config_t *cfg);

// 把任意来源的值钳到合法区间(网页提交、NVS 里的旧数据都可能越界)。
void vt_config_sanitize(vt_config_t *cfg);

// —— Wi-Fi 列表 ——
// 已存在同名 SSID 则覆盖密码;列表满返回 false。
bool vt_config_wifi_add(vt_config_t *cfg, const char *ssid, const char *pass);
bool vt_config_wifi_remove(vt_config_t *cfg, uint8_t index);
// 找到返回下标,否则返回 -1。
int vt_config_wifi_find(const vt_config_t *cfg, const char *ssid);

// —— 网页字段校验(与设备端共用同一套规则)——
// 用户名:UTF-8,含汉字/英文/数字,1..VT_NAME_MAX_BYTES 字节。
bool vt_config_check_name(const char *name);
// 房号:恰好 6 位数字。out 接收解析后的数值。
bool vt_config_check_room(const char *text, uint32_t *out);
// 密码:空串表示"不加密";非空必须是 4 位数字。
bool vt_config_check_pass(const char *text, uint16_t *out, bool *has_pass);

// —— 中转服务器(与设备端共用同一套规则)——
// 地址:空串合法,表示"不指定服务器"(设备退回局域网广播发现);
//       非空必须是 IPv4 点分十进制或域名(字母/数字/'-'/'.'/'_')。
//       这里只做字符形状校验,DNS 能不能解析要等联网才知道。
bool vt_config_check_host(const char *host);
// 端口:空串取 VT_SERVER_PORT_DEFAULT;非空必须是 1..65535 的十进制数字。
bool vt_config_check_port(const char *text, uint16_t *out);

#ifdef __cplusplus
}
#endif

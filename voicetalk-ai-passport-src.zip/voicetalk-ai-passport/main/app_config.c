// main/app_config.c —— app_config.h 的实现(纯逻辑)。
#include "app_config.h"

#include <string.h>

void vt_config_defaults(vt_config_t *cfg) {
    if (!cfg) return;
    memset(cfg, 0, sizeof(*cfg));
    cfg->name[0] = '\0';
    cfg->room = 0u;            // 000000
    cfg->passcode = 0u;
    cfg->has_pass = false;
    cfg->volume = 70u;
    cfg->brightness = 80u;
    cfg->transport = (uint8_t)VT_TRANSPORT_LAN;
    cfg->wifi_count = 0u;
    // 默认不指定服务器:与加这个字段之前一样,只用局域网广播发现。
    cfg->server_host[0] = '\0';
    cfg->server_port = VT_SERVER_PORT_DEFAULT;
}

void vt_config_sanitize(vt_config_t *cfg) {
    if (!cfg) return;

    cfg->name[VT_NAME_MAX_BYTES] = '\0';
    {
        const char *nul = memchr(cfg->name, '\0', VT_NAME_MAX_BYTES);
        size_t len = nul ? (size_t)(nul - cfg->name) : VT_NAME_MAX_BYTES;
        if (!vt_validate_name(cfg->name, len)) {
            cfg->name[0] = '\0';   // 非法名字一律退回"未设置",不保留半截 UTF-8
        }
    }
    if (cfg->room > VT_ROOM_MAX) cfg->room = VT_ROOM_MAX;
    if (cfg->has_pass && cfg->passcode > VT_PASS_MAX) cfg->passcode = 0u;
    if (!cfg->has_pass) cfg->passcode = 0u;
    if (cfg->volume > VT_VOLUME_MAX) cfg->volume = VT_VOLUME_MAX;
    if (cfg->brightness < VT_BRIGHTNESS_MIN) cfg->brightness = VT_BRIGHTNESS_MIN;
    if (cfg->brightness > VT_BRIGHTNESS_MAX) cfg->brightness = VT_BRIGHTNESS_MAX;
    if (cfg->transport != (uint8_t)VT_TRANSPORT_SERVER) {
        cfg->transport = (uint8_t)VT_TRANSPORT_LAN;
    }
    if (cfg->wifi_count > VT_WIFI_MAX) cfg->wifi_count = VT_WIFI_MAX;
    // 服务器地址:形状不对就整条丢掉,退回局域网发现 —— 留一个永远解析不出的
    // 域名只会让设备卡在"寻找中",还不如清掉让用户看到真实状态。
    cfg->server_host[VT_SERVER_HOST_MAX] = '\0';
    if (!vt_config_check_host(cfg->server_host)) cfg->server_host[0] = '\0';
    if (cfg->server_port < VT_SERVER_PORT_MIN || cfg->server_port > VT_SERVER_PORT_MAX) {
        cfg->server_port = VT_SERVER_PORT_DEFAULT;
    }
    for (uint8_t i = 0; i < cfg->wifi_count; i++) {
        cfg->wifi[i].ssid[VT_WIFI_SSID_MAX] = '\0';
        cfg->wifi[i].pass[VT_WIFI_PASS_MAX] = '\0';
        if (cfg->wifi[i].ssid[0] == '\0') {          // 空 SSID 视为无效条目
            vt_config_wifi_remove(cfg, i);
            i--;
        }
    }
}

int vt_config_wifi_find(const vt_config_t *cfg, const char *ssid) {
    if (!cfg || !ssid || ssid[0] == '\0') return -1;
    for (uint8_t i = 0; i < cfg->wifi_count; i++) {
        if (strncmp(cfg->wifi[i].ssid, ssid, VT_WIFI_SSID_MAX) == 0) return (int)i;
    }
    return -1;
}

bool vt_config_wifi_add(vt_config_t *cfg, const char *ssid, const char *pass) {
    if (!cfg || !ssid || ssid[0] == '\0') return false;
    const char *nul = memchr(ssid, '\0', VT_WIFI_SSID_MAX);
    size_t ssid_len = nul ? (size_t)(nul - ssid) : VT_WIFI_SSID_MAX;
    if (ssid_len == 0) return false;

    size_t pass_len = 0;
    if (pass) {
        const char *pnul = memchr(pass, '\0', VT_WIFI_PASS_MAX);
        pass_len = pnul ? (size_t)(pnul - pass) : VT_WIFI_PASS_MAX;
        // WPA2 最短 8 位;开放网络请留空
        if (pass_len != 0u && pass_len < 8u) return false;
    }

    int existing = vt_config_wifi_find(cfg, ssid);
    if (existing >= 0) {
        strncpy(cfg->wifi[existing].pass, pass ? pass : "", VT_WIFI_PASS_MAX);
        cfg->wifi[existing].pass[VT_WIFI_PASS_MAX] = '\0';
        return true;
    }
    if (cfg->wifi_count >= VT_WIFI_MAX) return false;

    vt_wifi_entry_t *slot = &cfg->wifi[cfg->wifi_count];
    memset(slot, 0, sizeof(*slot));
    strncpy(slot->ssid, ssid, VT_WIFI_SSID_MAX);
    slot->ssid[VT_WIFI_SSID_MAX] = '\0';
    strncpy(slot->pass, pass ? pass : "", VT_WIFI_PASS_MAX);
    slot->pass[VT_WIFI_PASS_MAX] = '\0';
    cfg->wifi_count++;
    return true;
}

bool vt_config_wifi_remove(vt_config_t *cfg, uint8_t index) {
    if (!cfg || index >= cfg->wifi_count) return false;
    for (uint8_t i = index; i + 1u < cfg->wifi_count; i++) {
        cfg->wifi[i] = cfg->wifi[i + 1];
    }
    cfg->wifi_count--;
    memset(&cfg->wifi[cfg->wifi_count], 0, sizeof(cfg->wifi[0]));
    return true;
}

bool vt_config_check_name(const char *name) {
    if (!name) return false;
    const char *nul = memchr(name, '\0', VT_NAME_MAX_BYTES + 1u);
    size_t len = nul ? (size_t)(nul - name) : VT_NAME_MAX_BYTES + 1u;
    return vt_validate_name(name, len);
}

bool vt_config_check_room(const char *text, uint32_t *out) {
    return vt_parse_room(text, out);
}

bool vt_config_check_pass(const char *text, uint16_t *out, bool *has_pass) {
    if (!text) return false;
    if (text[0] == '\0') {                 // 空 = 开放房间
        if (out) *out = 0u;
        if (has_pass) *has_pass = false;
        return true;
    }
    uint16_t value = 0;
    if (!vt_parse_passcode(text, &value)) return false;
    if (out) *out = value;
    if (has_pass) *has_pass = true;
    return true;
}

// 域名里允许的字符:字母、数字、'-'、'.'、'_'。
// IPv4 点分十进制是它的子集,所以一个函数两种写法都能收。
static bool host_char_ok(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
           (c >= '0' && c <= '9') || c == '-' || c == '.' || c == '_';
}

static bool host_starts_ok(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9');
}

bool vt_config_check_host(const char *host) {
    if (!host) return false;
    if (host[0] == '\0') return true;          // 空 = 不指定服务器

    size_t len = 0;
    while (host[len] != '\0') {
        if (!host_char_ok(host[len])) return false;
        if (++len > VT_SERVER_HOST_MAX) return false;
    }
    // 首字符必须是字母/数字:'-' 开头会被解析器当成选项,'.' 开头没有意义。
    if (!host_starts_ok(host[0])) return false;

    // 逐标签检查:标签不能为空(顺带排掉 ".." 和末尾的点),
    // 也不能以 '-' 开头或结尾 —— 这两类名字 DNS 里不合法,
    // 早拒掉比让设备卡在"解析失败"里好排查。
    size_t start = 0;
    for (size_t i = 0; i <= len; i++) {
        if (i == len || host[i] == '.') {
            if (i == start) return false;              // 空标签
            if (host[start] == '-') return false;
            if (host[i - 1u] == '-') return false;
            start = i + 1u;
        }
    }
    return true;
}

bool vt_config_check_port(const char *text, uint16_t *out) {
    if (!text) return false;
    if (text[0] == '\0') {                     // 留空 = 用默认端口
        if (out) *out = VT_SERVER_PORT_DEFAULT;
        return true;
    }
    uint32_t value = 0;
    size_t digits = 0;
    for (const char *p = text; *p != '\0'; p++) {
        if (*p < '0' || *p > '9') return false;   // 不接受 "+"/空格/十六进制
        value = value * 10u + (uint32_t)(*p - '0');
        if (++digits > 5u || value > VT_SERVER_PORT_MAX) return false;
    }
    if (value < VT_SERVER_PORT_MIN) return false;
    if (out) *out = (uint16_t)value;
    return true;
}

// main/app_storage.h —— 配置的 Flash(NVS)持久化。
//
// 与 app_config.h 的分工:后者管"值对不对",本文件管"怎么存"。
// 存失败一定要让调用方知道 —— 用户按了保存却没存住,比报错更糟。
#pragma once

#include "app_config.h"

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

// 打开 NVS(默认分区,"vt" 命名空间)。重复调用安全。
esp_err_t app_storage_init(void);

// 读配置;分区里没有记录时填出厂默认值并返回 ESP_OK。
esp_err_t app_storage_load(vt_config_t *out);

// 写配置。会先 vt_config_sanitize()。
esp_err_t app_storage_save(const vt_config_t *cfg);

// 恢复出厂设置:删掉本应用的所有键(不清 Wi-Fi 校准/PHY 数据)。
esp_err_t app_storage_reset(void);

#ifdef __cplusplus
}
#endif

// main/app_audio.c —— 半双工对讲音频。
//
// 关键取舍:
//   * 8 kHz / 16 bit / 单声道,20 ms 一帧(160 采样 = 320 字节)。
//     对讲要可懂度和低延迟,不是音乐质量;这个码率在 32 人房间里也扛得住。
//   * 发话期间不播放:半双工,避免回声与啸叫。收到的帧直接丢弃。
//   * 播放缓冲只留 6 帧(120 ms):宁可丢帧也不要把延迟攒成"对不上话"。
//   * 所有 PCM 读写都在本任务里,按键回调/网络任务只投递事件。
#include "app_audio.h"

#include "app_net.h"
#include "app_protocol.h"
#include "app_state.h"
#include "bsp_audio.h"

#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"

#include <string.h>

static const char *TAG = "vt_audio";

#define VT_RX_QUEUE_LEN 6u
#define VT_TX_MAX_MS 180000u     // 单次发话上限,防止按住不放把频道占死
#define VT_IDLE_POLL_MS 50u

typedef struct {
    uint8_t data[VT_AUDIO_FRAME_BYTES];
    uint16_t len;
} audio_frame_t;

static TaskHandle_t s_task;
static QueueHandle_t s_rx_queue;
static volatile bool s_tx;
static volatile bool s_tx_request;
static volatile bool s_rx_flush;
static uint32_t s_tx_start_ms;
static uint8_t s_volume = 70;

// 界面电平条用的峰值。写它的只有音频任务,读它的主要是 UI,uint8_t 足够原子。
static volatile uint8_t s_tx_level;
static volatile uint8_t s_rx_level;
static volatile uint32_t s_level_ms;

static uint32_t now_ms(void) {
    return (uint32_t)(xTaskGetTickCount() * portTICK_PERIOD_MS);
}

// 取一帧里的绝对峰值,线性映射到 0..100。对讲场景下人声的峰值通常只到
// 30~60,所以界面上的电平条大部分时间不会打满 —— 这是真实的,不要人为放大。
static uint8_t frame_level(const int16_t *pcm, size_t samples) {
    int32_t peak = 0;
    for (size_t i = 0; i < samples; i++) {
        int32_t v = pcm[i] < 0 ? -pcm[i] : pcm[i];
        if (v > peak) peak = v;
    }
    uint32_t level = (uint32_t)peak * 100u / 32768u;
    return level > 100u ? 100u : (uint8_t)level;
}

static void audio_task(void *arg) {
    (void)arg;
    int16_t mic[VT_AUDIO_FRAME_BYTES / 2];

    if (bsp_audio_set_format(VT_AUDIO_SAMPLE_HZ, 16, 1) != ESP_OK) {
        ESP_LOGE(TAG, "音频格式设置失败,通话不可用");
    }

    for (;;) {
        if (s_tx) {
            // —— 发话:采集 20 ms 送出去 ——
            if (now_ms() - s_tx_start_ms > VT_TX_MAX_MS) {
                ESP_LOGW(TAG, "发话超过 %u 秒,自动结束", VT_TX_MAX_MS / 1000);
                s_tx = false;
                app_state_lock();
                app_state()->talking = false;
                app_state_unlock();
                app_net_send_audio_end();
                continue;
            }
            if (bsp_audio_read(mic, sizeof(mic)) == ESP_OK) {
                s_tx_level = frame_level(mic, sizeof(mic) / 2);
                s_level_ms = now_ms();
                app_net_send_audio((const uint8_t *)mic, (uint16_t)sizeof(mic));
            } else {
                vTaskDelay(pdMS_TO_TICKS(5));
            }
        } else {
            if (s_tx_request) {                 // 刚松手:补一个结束包
                s_tx_request = false;
                app_net_send_audio_end();
            }
            if (s_rx_flush) {
                s_rx_flush = false;
                xQueueReset(s_rx_queue);
            }
            audio_frame_t frame;
            if (xQueueReceive(s_rx_queue, &frame, pdMS_TO_TICKS(VT_IDLE_POLL_MS)) == pdTRUE) {
                if (frame.len && bsp_audio_write(frame.data, frame.len) != ESP_OK) {
                    ESP_LOGD(TAG, "播放写入失败");
                } else {
                    s_rx_level = frame_level((const int16_t *)frame.data, frame.len / 2);
                    s_level_ms = now_ms();
                }
            }
        }
    }
}

esp_err_t app_audio_start(uint8_t volume_percent) {
    if (s_task) return ESP_OK;
    s_volume = volume_percent > 100u ? 100u : volume_percent;
    s_rx_queue = xQueueCreate(VT_RX_QUEUE_LEN, sizeof(audio_frame_t));
    if (!s_rx_queue) return ESP_ERR_NO_MEM;
    if (xTaskCreate(audio_task, "vt_audio", 4096, NULL, 6, &s_task) != pdPASS) {
        vQueueDelete(s_rx_queue);
        s_rx_queue = NULL;
        return ESP_ERR_NO_MEM;
    }
    return ESP_OK;
}

void app_audio_start_tx(void) {
    if (!s_task) return;
    if (bsp_audio_set_format(VT_AUDIO_SAMPLE_HZ, 16, 1) != ESP_OK) return;
    bsp_audio_set_volume(s_volume);
    s_tx_request = true;
    s_tx_start_ms = now_ms();
    s_tx = true;
    xQueueReset(s_rx_queue);          // 发话前清掉残留的别人语音
    app_state_lock();
    app_state()->talking = true;
    app_state_unlock();
}

void app_audio_stop_tx(void) {
    if (!s_tx) return;
    s_tx = false;
    app_state_lock();
    app_state()->talking = false;
    app_state_unlock();
}

bool app_audio_is_tx(void) {
    return s_tx;
}

bool app_audio_submit_rx(const uint8_t *frame, uint16_t len) {
    if (!s_rx_queue || !frame || len == 0 || len > VT_AUDIO_FRAME_BYTES) return false;
    if (s_tx) return false;           // 半双工:发话时不接收
    audio_frame_t item;
    memcpy(item.data, frame, len);
    item.len = len;
    // 满了就丢最旧的,保证播放端永远追得上"现在"。
    if (xQueueSend(s_rx_queue, &item, 0) != pdTRUE) {
        audio_frame_t dropped;
        if (xQueueReceive(s_rx_queue, &dropped, 0) == pdTRUE) {
            xQueueSend(s_rx_queue, &item, 0);
        }
    }
    return true;
}

void app_audio_rx_end(void) {
    s_rx_flush = true;
}

uint8_t app_audio_level(void) {
    uint8_t raw = s_tx ? s_tx_level : s_rx_level;
    uint32_t age = now_ms() - s_level_ms;      // 无符号减法,回绕也安全
    if (age >= 600u) return 0u;                // 早就没有新帧了
    if (age <= 100u) return raw;               // 100 ms 内按原值显示
    return (uint8_t)((uint32_t)raw * (600u - age) / 500u);   // 之后线性淡出
}

void app_audio_set_volume(uint8_t percent) {
    s_volume = percent > 100u ? 100u : percent;
    bsp_audio_set_volume(s_volume);
}

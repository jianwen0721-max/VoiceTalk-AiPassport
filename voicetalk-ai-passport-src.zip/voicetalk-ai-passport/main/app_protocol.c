// main/app_protocol.c —— app_protocol.h 的实现。只依赖 C 标准库,便于主机单测。
#include "app_protocol.h"

#include <string.h>

// 房间密钥:把房号与密码混成一个 32 位值。用整数混合而不是 memcpy,
// 保证大小端平台得到同一个值(中转服务器是 Python,也要能算出一模一样的结果)。
uint32_t vt_room_key(uint32_t room, uint16_t passcode, bool has_pass) {
    if (!has_pass) return 0u;
    uint32_t h = 0x811C9DC5u;                 // FNV-1a 32 偏移基数
    h ^= room & 0xFFu;         h *= 0x01000193u;
    h ^= (room >> 8) & 0xFFu;  h *= 0x01000193u;
    h ^= (room >> 16) & 0xFFu; h *= 0x01000193u;
    h ^= (passcode & 0xFFu);       h *= 0x01000193u;
    h ^= (passcode >> 8) & 0xFFu;  h *= 0x01000193u;
    return h == 0u ? 1u : h;                  // 0 留给"无密码"
}

bool vt_parse_passcode(const char *text, uint16_t *out) {
    if (!text) return false;
    uint16_t value = 0;
    for (size_t i = 0; i < VT_PASS_DIGITS; i++) {
        char c = text[i];
        if (c < '0' || c > '9') return false;
        value = (uint16_t)(value * 10u + (uint16_t)(c - '0'));
    }
    if (text[VT_PASS_DIGITS] != '\0') return false;  // 必须是恰好 4 位
    if (out) *out = value;
    return true;
}

bool vt_parse_room(const char *text, uint32_t *out) {
    if (!text) return false;
    uint32_t value = 0;
    for (size_t i = 0; i < VT_ROOM_DIGITS; i++) {
        char c = text[i];
        if (c < '0' || c > '9') return false;
        value = value * 10u + (uint32_t)(c - '0');
    }
    if (text[VT_ROOM_DIGITS] != '\0') return false;  // 必须是恰好 6 位
    if (out) *out = value;
    return true;
}

void vt_format_room(uint32_t room, char out[VT_ROOM_DIGITS + 1]) {
    if (room > VT_ROOM_MAX) room = VT_ROOM_MAX;
    for (int i = (int)VT_ROOM_DIGITS - 1; i >= 0; i--) {
        out[i] = (char)('0' + (room % 10u));
        room /= 10u;
    }
    out[VT_ROOM_DIGITS] = '\0';
}

// UTF-8 校验:拒绝超长编码、 surrogate、5 字节以上序列与截断序列。
// 用户名可以是汉字,但必须是合法 UTF-8 —— 否则 LVGL 会画出乱码或空格。
static size_t utf8_next(const uint8_t *s, size_t len, size_t i, uint32_t *cp) {
    uint8_t c = s[i];
    size_t need;
    uint32_t value;
    if (c < 0x80u) { *cp = c; return 1; }
    if ((c & 0xE0u) == 0xC0u)      { need = 2; value = c & 0x1Fu; }
    else if ((c & 0xF0u) == 0xE0u) { need = 3; value = c & 0x0Fu; }
    else if ((c & 0xF8u) == 0xF0u) { need = 4; value = c & 0x07u; }
    else return 0;
    if (i + need > len) return 0;
    for (size_t k = 1; k < need; k++) {
        uint8_t cc = s[i + k];
        if ((cc & 0xC0u) != 0x80u) return 0;
        value = (value << 6) | (uint32_t)(cc & 0x3Fu);
    }
    if (need == 2 && value < 0x80u) return 0;            // 超长编码
    if (need == 3 && value < 0x800u) return 0;
    if (need == 4 && value < 0x10000u) return 0;
    if (value >= 0xD800u && value <= 0xDFFFu) return 0;  // surrogate
    if (value > 0x10FFFFu) return 0;
    *cp = value;
    return need;
}

int vt_utf8_length(const char *utf8, size_t len) {
    if (!utf8) return -1;
    const uint8_t *s = (const uint8_t *)utf8;
    int count = 0;
    size_t i = 0;
    while (i < len) {
        uint32_t cp = 0;
        size_t step = utf8_next(s, len, i, &cp);
        if (step == 0) return -1;
        i += step;
        count++;
    }
    return count;
}

bool vt_validate_name(const char *utf8, size_t len) {
    if (!utf8 || len == 0) return false;
    if (len > VT_NAME_MAX_BYTES) return false;
    // 名字里不能有 NUL。用 memchr 而不是 strnlen:后者是 POSIX 函数,
    // 主机测试用 -std=c11 严格模式编译时不可见。
    if (memchr(utf8, '\0', len)) return false;
    const uint8_t *s = (const uint8_t *)utf8;
    bool has_visible = false;
    size_t i = 0;
    while (i < len) {
        uint32_t cp = 0;
        size_t step = utf8_next(s, len, i, &cp);
        if (step == 0) return false;
        // 控制字符一律拒绝(换行会把 UI 布局弄乱,C0/C1 不该出现在名字里)
        if (cp < 0x20u || cp == 0x7Fu || (cp >= 0x80u && cp <= 0x9Fu)) return false;
        if (cp != 0x20u && cp != 0x3000u) has_visible = true;  // 全角空格也不算内容
        i += step;
    }
    return has_visible;
}

size_t vt_encode(uint8_t *out, size_t out_cap, vt_pkt_type_t type, uint32_t room,
                 uint16_t sender, uint16_t seq, uint16_t flags,
                 const void *payload, uint16_t payload_len) {
    if (!out) return 0;
    if (payload_len > VT_MAX_PAYLOAD) return 0;
    if (payload_len && !payload) return 0;
    size_t total = (size_t)VT_HEADER_SIZE + payload_len;
    if (out_cap < total) return 0;
    if (room > VT_ROOM_MAX) return 0;

    out[0] = VT_MAGIC0;
    out[1] = VT_MAGIC1;
    out[2] = VT_VERSION;
    out[3] = (uint8_t)type;
    out[4] = (uint8_t)((room >> 24) & 0xFFu);
    out[5] = (uint8_t)((room >> 16) & 0xFFu);
    out[6] = (uint8_t)((room >> 8) & 0xFFu);
    out[7] = (uint8_t)(room & 0xFFu);
    out[8] = (uint8_t)((sender >> 8) & 0xFFu);
    out[9] = (uint8_t)(sender & 0xFFu);
    out[10] = (uint8_t)((seq >> 8) & 0xFFu);
    out[11] = (uint8_t)(seq & 0xFFu);
    out[12] = (uint8_t)((payload_len >> 8) & 0xFFu);
    out[13] = (uint8_t)(payload_len & 0xFFu);
    out[14] = (uint8_t)((flags >> 8) & 0xFFu);
    out[15] = (uint8_t)(flags & 0xFFu);
    if (payload_len) memcpy(out + VT_HEADER_SIZE, payload, payload_len);
    return total;
}

bool vt_decode(const uint8_t *buf, size_t len, vt_packet_t *out) {
    if (!buf || !out || len < VT_HEADER_SIZE) return false;
    if (buf[0] != VT_MAGIC0 || buf[1] != VT_MAGIC1) return false;
    if (buf[2] != VT_VERSION) return false;
    uint16_t payload_len = (uint16_t)(((uint16_t)buf[12] << 8) | buf[13]);
    if (payload_len > VT_MAX_PAYLOAD) return false;
    if (len < (size_t)VT_HEADER_SIZE + payload_len) return false;
    uint32_t room = ((uint32_t)buf[4] << 24) | ((uint32_t)buf[5] << 16) |
                    ((uint32_t)buf[6] << 8) | (uint32_t)buf[7];
    if (room > VT_ROOM_MAX) return false;

    out->version = buf[2];
    out->type = (vt_pkt_type_t)buf[3];
    out->room = room;
    out->sender = (uint16_t)(((uint16_t)buf[8] << 8) | buf[9]);
    out->seq = (uint16_t)(((uint16_t)buf[10] << 8) | buf[11]);
    out->flags = (uint16_t)(((uint16_t)buf[14] << 8) | buf[15]);
    out->payload_len = payload_len;
    out->payload = payload_len ? buf + VT_HEADER_SIZE : NULL;
    return true;
}

size_t vt_encode_hello(uint8_t *out, size_t out_cap, const char *name, uint32_t key) {
    if (!out || !name) return 0;
    const char *nul = memchr(name, '\0', VT_NAME_MAX_BYTES);
    size_t name_len = nul ? (size_t)(nul - name) : VT_NAME_MAX_BYTES;
    if (name_len == 0 || name_len > VT_NAME_MAX_BYTES) return 0;
    if (!vt_validate_name(name, name_len)) return 0;
    size_t total = 1u + name_len + 4u;
    if (out_cap < total) return 0;
    out[0] = (uint8_t)name_len;
    memcpy(out + 1, name, name_len);
    uint8_t *p = out + 1 + name_len;
    p[0] = (uint8_t)((key >> 24) & 0xFFu);
    p[1] = (uint8_t)((key >> 16) & 0xFFu);
    p[2] = (uint8_t)((key >> 8) & 0xFFu);
    p[3] = (uint8_t)(key & 0xFFu);
    return total;
}

bool vt_decode_hello(const uint8_t *payload, uint16_t len, char *name_out,
                     size_t name_cap, uint32_t *key_out) {
    if (!payload || len < 5u) return false;
    size_t name_len = payload[0];
    if (name_len == 0 || name_len > VT_NAME_MAX_BYTES) return false;
    if ((size_t)len < 1u + name_len + 4u) return false;
    if (!vt_validate_name((const char *)payload + 1, name_len)) return false;
    if (name_out && name_cap) {
        if (name_cap < name_len + 1u) return false;
        memcpy(name_out, payload + 1, name_len);
        name_out[name_len] = '\0';
    }
    const uint8_t *p = payload + 1 + name_len;
    if (key_out) {
        *key_out = ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
                   ((uint32_t)p[2] << 8) | (uint32_t)p[3];
    }
    return true;
}

void vt_scramble(uint8_t *data, uint16_t len, uint32_t key, uint16_t seq) {
    if (!data || len == 0 || key == 0u) return;
    // 每个包的 keystream 带 seq,避免同一段静音在每帧产生相同的密文。
    uint32_t state = key ^ (0x9E3779B9u + (uint32_t)seq * 0x85EBCA6Bu);
    for (uint16_t i = 0; i < len; i++) {
        state ^= state << 13;
        state ^= state >> 17;
        state ^= state << 5;
        data[i] ^= (uint8_t)(state & 0xFFu);
    }
}

// main/app_web.h —— 网页设置(手机连设备热点后打开 192.168.4.1)。
//
// 只有"打开网页设置"时才起 HTTP 服务器:C3 内存紧张,平时不要白占着。
// 使用者的名称、房间号、房间密码都只在这里改;设备端设置页不提供这几项输入
// (三键输 6 位房号和汉字名字太难用)。
#pragma once

#include "esp_err.h"

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

// 启动 HTTP 服务器(已启动则直接返回 ESP_OK)。
esp_err_t app_web_start(void);
void app_web_stop(void);
bool app_web_running(void);

// 网页热点地址,形如 "192.168.4.1"(给 UI 显示用)。
const char *app_web_ap_ip(void);

#ifdef __cplusplus
}
#endif

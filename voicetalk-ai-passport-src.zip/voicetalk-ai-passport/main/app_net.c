// main/app_net.c —— Wi-Fi / UDP 线路 / 服务器发现 / NTP。
#include "app_net.h"

#include "app_audio.h"
#include "app_state.h"
#include "app_storage.h"

#include "esp_log.h"
#include "esp_netif.h"
#include "esp_mac.h"
#include "esp_random.h"
#include "esp_sntp.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "lwip/inet.h"
#include "lwip/netdb.h"
#include "lwip/sockets.h"

#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static const char *TAG = "vt_net";

#define VT_HELLO_INTERVAL_MS 2000u
#define VT_DISCOVER_INTERVAL_MS 5000u
#define VT_RX_TICK_MS 100u
#define VT_MAX_SILENT_MS 1000u   // 多久没收到语音就停播(防对端异常退出)

// —— 互联网中转服务器 ——
// 域名可能因为换接入点/DDNS 更新而换 IP,所以定期重新解析一次;
// 30 秒对"搬家了要重连"足够快,又不至于一直占着 DNS。
#define VT_SERVER_RESOLVE_INTERVAL_MS 30000u
// 探活间隔。跨公网时这个包还有第二个作用:NAT 保活。设备一直在发,
// 路由器才一直留着那条映射,服务器转回来的语音才进得来。
// 3 秒远小于家用路由器常见的 30~120 秒 UDP 映射老化时间。
#define VT_SERVER_PROBE_INTERVAL_MS 3000u
// 多久没收到服务器侧的报文就认为这条链路断了(回退到"寻找中",仍可通话)。
#define VT_SERVER_TIMEOUT_MS 12000u

static TaskHandle_t s_task;
static int s_sock = -1;
static bool s_started;
static bool s_sta_ready;          // Wi-Fi 驱动起来且已下发了连接配置
static uint8_t s_wifi_try_index;
static uint32_t s_broadcast_addr; // 本网段广播地址(网络序)
static uint16_t s_seq;
static bool s_time_requested;

// 上次成功解析的服务器名字:名字一变(网页改过)就立刻重新解析,不必等 30 秒。
static char s_resolved_host[VT_SERVER_HOST_MAX + 1];
static uint32_t s_last_resolve_ms;
static uint32_t s_last_probe_ms;

// —— 事件回调:只做轻量记账,重活都留给 net 任务 ——
static void on_wifi_event(void *arg, esp_event_base_t base, int32_t id, void *data) {
    (void)arg;
    app_state_lock();
    app_state_t *st = app_state();
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        st->link = VT_LINK_DOWN;
        st->ip[0] = '\0';
        ESP_LOGW(TAG, "Wi-Fi 断开(%s)", st->ssid);
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_CONNECTED) {
        wifi_event_sta_connected_t *ev = (wifi_event_sta_connected_t *)data;
        snprintf(st->ssid, sizeof(st->ssid), "%.*s", (int)sizeof(ev->ssid), ev->ssid);
        st->link = VT_LINK_CONNECTING;
        ESP_LOGI(TAG, "已关联 AP: %s", st->ssid);
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_AP_STACONNECTED) {
        ESP_LOGI(TAG, "有设备连上了网页设置热点");
    }
    app_state_unlock();
}

static void on_ip_event(void *arg, esp_event_base_t base, int32_t id, void *data) {
    (void)arg;
    (void)base;
    if (id != IP_EVENT_STA_GOT_IP) return;
    ip_event_got_ip_t *ev = (ip_event_got_ip_t *)data;

    char ipstr[16];
    esp_ip4addr_ntoa(&ev->ip_info.ip, ipstr, sizeof(ipstr));

    app_state_lock();
    app_state_t *st = app_state();
    st->link = VT_LINK_UP;
    snprintf(st->ip, sizeof(st->ip), "%s", ipstr);
    st->rssi = 0;
    // 本网段广播地址
    s_broadcast_addr = (ev->ip_info.ip.addr & ev->ip_info.netmask.addr) |
                       (~ev->ip_info.netmask.addr);
    app_state_unlock();

    ESP_LOGI(TAG, "拿到 IP: %s", ipstr);
}

static esp_err_t wifi_stack_start(void) {
    // netif / event loop / Wi-Fi 驱动只需要起来一次。
    static bool s_stack_ready;
    if (s_stack_ready) return ESP_OK;

    esp_err_t err = esp_netif_init();
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) return err;
    err = esp_event_loop_create_default();
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) return err;

    esp_netif_t *sta = esp_netif_create_default_wifi_sta();
    esp_netif_t *ap = esp_netif_create_default_wifi_ap();
    if (!sta || !ap) return ESP_ERR_NO_MEM;

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    err = esp_wifi_init(&cfg);
    if (err != ESP_OK) return err;

    err = esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, on_wifi_event, NULL);
    if (err != ESP_OK) return err;
    err = esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, on_ip_event, NULL);
    if (err != ESP_OK) return err;

    err = esp_wifi_set_storage(WIFI_STORAGE_RAM);
    if (err != ESP_OK) return err;
    // STA + AP 共存:AP 用于手机连上来做网页设置,不需要时也不必拆栈。
    err = esp_wifi_set_mode(WIFI_MODE_APSTA);
    if (err != ESP_OK) return err;

    wifi_config_t ap_cfg = { 0 };
    uint8_t mac[6];
    esp_read_mac(mac, ESP_MAC_WIFI_SOFTAP);
    snprintf((char *)ap_cfg.ap.ssid, sizeof(ap_cfg.ap.ssid), "VoiceTalk-%02X%02X",
             mac[4], mac[5]);
    ap_cfg.ap.ssid_len = (uint8_t)strlen((char *)ap_cfg.ap.ssid);
    ap_cfg.ap.channel = 1;
    ap_cfg.ap.max_connection = 2;
    ap_cfg.ap.authmode = WIFI_AUTH_OPEN;   // 配置用热点,只在用户主动开启时才有意义
    err = esp_wifi_set_config(WIFI_IF_AP, &ap_cfg);
    if (err != ESP_OK) return err;

    err = esp_wifi_start();
    if (err != ESP_OK) return err;

    app_state_lock();
    app_state()->ap_on = true;
    app_state_unlock();

    s_stack_ready = true;
    return ESP_OK;
}

// 用列表里的下一个 Wi-Fi 去连;全试完就回到第 0 个(路由器可能只是暂时不通)。
static void connect_next_wifi(void) {
    vt_config_t cfg;
    app_state_lock();
    cfg = app_state()->cfg;
    app_state_unlock();

    uint8_t count = cfg.wifi_count;
    if (count == 0) {
        app_state_lock();
        app_state()->link = VT_LINK_DOWN;
        app_state_unlock();
        return;
    }

    /* 优先连接当前可见且信号最强的已保存网络；扫描失败时回退到轮询策略。 */
    uint8_t index = s_wifi_try_index % count;
    wifi_scan_config_t scan_cfg = { 0 };
    if (esp_wifi_scan_start(&scan_cfg, true) == ESP_OK) {
        uint16_t found = 0;
        if (esp_wifi_scan_get_ap_num(&found) == ESP_OK && found > 0) {
            if (found > 30) found = 30;
            wifi_ap_record_t *records = calloc(found, sizeof(*records));
            if (records) {
                uint16_t got = found;
                if (esp_wifi_scan_get_ap_records(&got, records) == ESP_OK) {
                    int best_rssi = -127;
                    for (uint16_t r = 0; r < got; r++) {
                        for (uint8_t i = 0; i < count; i++) {
                            if (cfg.wifi[i].ssid[0] &&
                                strncmp(cfg.wifi[i].ssid, (const char *)records[r].ssid,
                                        VT_WIFI_SSID_MAX) == 0 &&
                                records[r].rssi > best_rssi) {
                                best_rssi = records[r].rssi;
                                index = i;
                            }
                        }
                    }
                    if (best_rssi > -127) {
                        ESP_LOGI(TAG, "选择信号最强的已保存 Wi-Fi: %s (%d dBm)",
                                 cfg.wifi[index].ssid, best_rssi);
                    }
                }
                free(records);
            }
        }
    }

    wifi_config_t sta = { 0 };
    strncpy((char *)sta.sta.ssid, cfg.wifi[index].ssid, sizeof(sta.sta.ssid) - 1);
    strncpy((char *)sta.sta.password, cfg.wifi[index].pass, sizeof(sta.sta.password) - 1);
    sta.sta.scan_method = WIFI_FAST_SCAN;
    sta.sta.failure_retry_cnt = 1;
    app_state_lock();
    app_state()->link = VT_LINK_CONNECTING;
    app_state_unlock();

    esp_err_t err = esp_wifi_set_config(WIFI_IF_STA, &sta);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "写入 STA 配置失败: %s", esp_err_to_name(err));
        return;
    }
    err = esp_wifi_connect();
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "发起连接失败: %s", esp_err_to_name(err));
    }
}

static int ensure_socket(void) {
    if (s_sock >= 0) return s_sock;
    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0) return -1;

    int yes = 1;
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    setsockopt(sock, SOL_SOCKET, SO_BROADCAST, &yes, sizeof(yes));

    struct sockaddr_in bind_addr = { 0 };
    bind_addr.sin_family = AF_INET;
    bind_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    bind_addr.sin_port = htons(VT_UDP_PORT);
    if (bind(sock, (struct sockaddr *)&bind_addr, sizeof(bind_addr)) < 0) {
        close(sock);
        return -1;
    }
    int flags = fcntl(sock, F_GETFL, 0);
    if (flags >= 0) fcntl(sock, F_SETFL, flags | O_NONBLOCK);

    s_sock = sock;
    return s_sock;
}

static void send_packet(int sock, vt_pkt_type_t type, const void *payload,
                        uint16_t len, uint32_t dest, uint16_t port) {
    uint8_t buf[VT_HEADER_SIZE + VT_MAX_PAYLOAD];
    app_state_lock();
    uint32_t room = app_state()->cfg.room;
    uint16_t self = app_state()->self_id;
    uint32_t key = app_state()->cfg.has_pass
                 ? vt_room_key(room, app_state()->cfg.passcode, true)
                 : 0u;
    app_state_unlock();

    uint16_t flags = (key != 0u && type == VT_PKT_AUDIO) ? VT_FLAG_ENCRYPTED : 0u;
    size_t total = vt_encode(buf, sizeof(buf), type, room, self, s_seq++, flags,
                             payload, len);
    if (total == 0) return;

    struct sockaddr_in to = { 0 };
    to.sin_family = AF_INET;
    to.sin_port = htons(port);
    to.sin_addr.s_addr = dest;
    // 发不出去就丢:对讲宁可少一帧,也不要在这里阻塞。
    if (sendto(sock, buf, total, 0, (struct sockaddr *)&to, sizeof(to)) < 0) {
        ESP_LOGD(TAG, "sendto 失败 errno=%d", errno);
    }
}

// —— 互联网中转服务器 ——
// 解析服务器地址:纯 IP 字面量直接换算,省一次 DNS 查询;其余交给 getaddrinfo。
// 返回 0 表示解析失败。
//
// ⚠ getaddrinfo 会阻塞(DNS 无响应时要等几秒),所以只允许在网络任务里调用,
//   绝不能在按键回调或 LVGL 上下文里调。
static uint32_t resolve_server_host(const char *host) {
    if (!host || host[0] == '\0') return 0u;

    uint32_t literal = inet_addr(host);
    if (literal != INADDR_NONE && literal != INADDR_ANY) return literal;

    struct addrinfo hints = { 0 };
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_DGRAM;

    struct addrinfo *res = NULL;
    if (getaddrinfo(host, NULL, &hints, &res) != 0 || res == NULL) return 0u;

    uint32_t addr = 0u;
    if (res->ai_addr != NULL && (size_t)res->ai_addrlen >= sizeof(struct sockaddr_in)) {
        const struct sockaddr_in *sa = (const struct sockaddr_in *)res->ai_addr;
        addr = sa->sin_addr.s_addr;
    }
    freeaddrinfo(res);
    return addr;
}

typedef struct {
    uint32_t addr;
    uint16_t port;
} vt_target_t;

// 选一个发包目标,优先级:
//   1) 网页填的服务器地址且已解析 → 单播过去(可跨公网,这是互联网通话的主路径)
//   2) 局域网广播发现到的中转服务器(没填地址时的兜底)
//   3) 本网段广播(同一 Wi-Fi 下设备直连)
static vt_target_t pick_target(void) {
    vt_target_t t;

    app_state_lock();
    uint8_t transport = app_state()->cfg.transport;
    bool relay = app_state()->relay_seen;
    uint32_t relay_addr = app_state()->relay_addr;
    uint16_t relay_port = app_state()->relay_port;
    uint32_t server_addr = app_state()->server_addr;
    uint16_t server_port = app_state()->server_port;
    app_state_unlock();

    if (transport == (uint8_t)VT_TRANSPORT_SERVER) {
        if (server_addr != 0u) {
            t.addr = server_addr;
            t.port = server_port ? server_port : VT_SERVER_PORT_DEFAULT;
            return t;
        }
        if (relay) {
            t.addr = relay_addr;
            t.port = relay_port ? relay_port : VT_UDP_PORT;
            return t;
        }
    }
    t.addr = s_broadcast_addr ? s_broadcast_addr : htonl(INADDR_BROADCAST);
    t.port = VT_UDP_PORT;
    return t;
}

// 维护互联网服务器这条链路:解析域名、定期探活、判定是否还活着。
// 只在网络任务里调用(内部会阻塞式解析 DNS)。
static void update_server(uint32_t now) {
    app_state_lock();
    char host[VT_SERVER_HOST_MAX + 1];
    strncpy(host, app_state()->cfg.server_host, sizeof(host) - 1);
    host[sizeof(host) - 1] = '\0';
    uint16_t port = app_state()->cfg.server_port;
    uint8_t transport = app_state()->cfg.transport;
    uint32_t addr = app_state()->server_addr;
    app_state_unlock();

    const bool configured = (host[0] != '\0');
    if (transport != (uint8_t)VT_TRANSPORT_SERVER || !configured) {
        if (addr != 0u) {
            app_state_lock();
            app_state()->server_addr = 0u;
            app_state()->server_state = VT_SERVER_NONE;
            app_state()->server_last_rx = 0u;
            app_state_unlock();
            s_resolved_host[0] = '\0';
        }
        return;
    }

    const uint16_t use_port = port ? port : VT_SERVER_PORT_DEFAULT;
    app_state_lock();
    app_state()->server_port = use_port;
    app_state_unlock();

    // 没解析过 / 名字改了 / 到期了 → 重新解析一次。
    const bool need_resolve = (addr == 0u) ||
                              (strcmp(s_resolved_host, host) != 0) ||
                              (now - s_last_resolve_ms >= VT_SERVER_RESOLVE_INTERVAL_MS);
    if (need_resolve) {
        s_last_resolve_ms = now;
        uint32_t resolved = resolve_server_host(host);
        app_state_lock();
        app_state_t *st = app_state();
        st->server_addr = resolved;
        if (resolved == 0u) {
            st->server_state = VT_SERVER_FAILED;
        } else if (st->server_state != VT_SERVER_ONLINE) {
            st->server_state = VT_SERVER_SEEKING;
        }
        app_state_unlock();

        if (resolved == 0u) {
            ESP_LOGW(TAG, "解析服务器地址失败: %s(将退回局域网)", host);
            s_resolved_host[0] = '\0';
            return;
        }
        strncpy(s_resolved_host, host, sizeof(s_resolved_host) - 1);
        s_resolved_host[sizeof(s_resolved_host) - 1] = '\0';
        ESP_LOGI(TAG, "服务器 %s -> %u.%u.%u.%u:%u", host,
                 (unsigned)(resolved & 0xFF), (unsigned)((resolved >> 8) & 0xFF),
                 (unsigned)((resolved >> 16) & 0xFF), (unsigned)((resolved >> 24) & 0xFF),
                 (unsigned)use_port);
        addr = resolved;
    }

    // 探活 + NAT 保活。
    if (addr != 0u && now - s_last_probe_ms >= VT_SERVER_PROBE_INTERVAL_MS) {
        s_last_probe_ms = now;
        int sock = ensure_socket();
        if (sock >= 0) {
            send_packet(sock, VT_PKT_DISCOVER, NULL, 0, addr, use_port);
        }
    }

    // 太久没收到服务器侧的报文 → 退回"寻找中"(仍能走局域网/广播通话)。
    app_state_lock();
    app_state_t *st = app_state();
    if (st->server_state == VT_SERVER_ONLINE &&
        (uint32_t)(now - st->server_last_rx) > VT_SERVER_TIMEOUT_MS) {
        st->server_state = VT_SERVER_SEEKING;
        ESP_LOGW(TAG, "服务器超时无应答,退回寻找中");
    }
    app_state_unlock();
}

static void send_audio_frame(const uint8_t *pcm, uint16_t len) {
    int sock = ensure_socket();
    if (sock < 0) return;

    const vt_target_t target = pick_target();

    // 有密码的房间先把 PCM 加扰再发(轻量隔离,不是加密学意义的加密)。
    if (len && len <= VT_AUDIO_FRAME_BYTES) {
        app_state_lock();
        uint32_t key = app_state()->cfg.has_pass
                     ? vt_room_key(app_state()->cfg.room, app_state()->cfg.passcode, true)
                     : 0u;
        app_state_unlock();
        uint8_t frame[VT_AUDIO_FRAME_BYTES];
        memcpy(frame, pcm, len);
        if (key) vt_scramble(frame, len, key, s_seq);
        send_packet(sock, VT_PKT_AUDIO, frame, len, target.addr, target.port);
    }
}

void app_net_send_audio(const uint8_t *pcm, uint16_t len) {
    if (!pcm || len == 0) return;
    send_audio_frame(pcm, len);
}

void app_net_send_audio_end(void) {
    int sock = ensure_socket();
    if (sock < 0) return;
    const vt_target_t target = pick_target();
    send_packet(sock, VT_PKT_AUDIO_END, NULL, 0, target.addr, target.port);
}

void app_net_send_hello_now(void) {
    int sock = ensure_socket();
    if (sock < 0) return;

    uint8_t payload[1 + VT_NAME_MAX_BYTES + 4];
    app_state_lock();
    char name[VT_NAME_MAX_BYTES + 1];
    strncpy(name, app_state()->cfg.name, sizeof(name) - 1);
    name[sizeof(name) - 1] = '\0';
    uint32_t room = app_state()->cfg.room;
    uint32_t key = app_state()->cfg.has_pass
                 ? vt_room_key(room, app_state()->cfg.passcode, true)
                 : 0u;
    app_state_unlock();

    if (name[0] == '\0') snprintf(name, sizeof(name), "无名用户");

    size_t n = vt_encode_hello(payload, sizeof(payload), name, key);
    if (n == 0) return;

    app_state_lock();
    uint8_t transport = app_state()->cfg.transport;
    bool relay = app_state()->relay_seen;
    uint32_t server_addr = app_state()->server_addr;
    app_state_unlock();

    const vt_target_t target = pick_target();
    send_packet(sock, VT_PKT_HELLO, payload, (uint16_t)n, target.addr, target.port);

    // 服务器模式下,若既没解析出服务器地址、也没在局域网里发现中转,
    // 就广播问一句"服务器在吗"(不依赖已有地址)。
    if (transport == (uint8_t)VT_TRANSPORT_SERVER && !relay && server_addr == 0u) {
        send_packet(sock, VT_PKT_DISCOVER, NULL, 0,
                    s_broadcast_addr ? s_broadcast_addr : htonl(INADDR_BROADCAST),
                    VT_UDP_PORT);
    }
}

static void send_bye(void) {
    int sock = ensure_socket();
    if (sock < 0) return;
    const vt_target_t target = pick_target();
    send_packet(sock, VT_PKT_BYE, NULL, 0, target.addr, target.port);
}

static void handle_packet(const uint8_t *buf, size_t len, uint32_t src_addr) {
    vt_packet_t pkt;
    if (!vt_decode(buf, len, &pkt)) return;

    app_state_lock();
    app_state_t *st = app_state();
    if (pkt.sender == st->self_id) { app_state_unlock(); return; }   // 自己发的
    uint32_t my_room = st->cfg.room;
    uint32_t my_key = st->cfg.has_pass
                    ? vt_room_key(my_room, st->cfg.passcode, true) : 0u;
    app_state_unlock();

    if (pkt.room != my_room) return;   // 别的房间,不关我们的事

    uint32_t now = (uint32_t)(xTaskGetTickCount() * portTICK_PERIOD_MS);

    // 来自服务器的报文 —— 无论是它应答 DISCOVER,还是它转来的同伴语音 ——
    // 都说明"设备 <-> 公网服务器"这条链路现在是通的。
    app_state_lock();
    if (app_state()->server_addr != 0u && src_addr == app_state()->server_addr) {
        app_state()->server_state = VT_SERVER_ONLINE;
        app_state()->server_last_rx = now;
    }
    app_state_unlock();

    switch (pkt.type) {
    case VT_PKT_HELLO: {
        char name[VT_NAME_MAX_BYTES + 1];
        uint32_t key = 0;
        if (!vt_decode_hello(pkt.payload, pkt.payload_len, name, sizeof(name), &key)) return;
        if (key != my_key) {
            // 密码不一致:不进名单、不通话。日志只打一次级别,避免刷屏。
            ESP_LOGD(TAG, "忽略密码不一致的 HELLO(sender=%u)", pkt.sender);
            return;
        }
        app_state_lock();
        vt_roster_upsert(&app_state()->roster, pkt.sender, name, now);
        app_state_unlock();
        break;
    }
    case VT_PKT_BYE:
        app_state_lock();
        vt_roster_remove(&app_state()->roster, pkt.sender);
        app_state_unlock();
        break;
    case VT_PKT_AUDIO: {
        if (!pkt.payload || pkt.payload_len == 0 || pkt.payload_len > VT_AUDIO_FRAME_BYTES) {
            return;
        }
        if (pkt.flags & VT_FLAG_ENCRYPTED) {
            if (my_key == 0u) return;             // 我们在开放房间,听不懂加密房
            uint8_t frame[VT_AUDIO_FRAME_BYTES];
            memcpy(frame, pkt.payload, pkt.payload_len);
            vt_scramble(frame, pkt.payload_len, my_key, pkt.seq);
            app_audio_submit_rx(frame, pkt.payload_len);
        } else {
            if (my_key != 0u) return;             // 我们在加密房间,不听明文
            app_audio_submit_rx(pkt.payload, pkt.payload_len);
        }
        app_state_lock();
        vt_roster_note_audio(&app_state()->roster, pkt.sender, now);
        app_state_unlock();
        break;
    }
    case VT_PKT_AUDIO_END:
        app_state_lock();
        vt_roster_end_audio(&app_state()->roster, pkt.sender);
        app_state_unlock();
        app_audio_rx_end();
        break;
    case VT_PKT_SERVER_HERE: {
        if (pkt.payload_len >= 2) {
            uint16_t port = (uint16_t)((pkt.payload[0] << 8) | pkt.payload[1]);
            app_state_lock();
            app_state_t *st2 = app_state();
            if (st2->server_addr != 0u && src_addr == st2->server_addr) {
                // 网页填的那个服务器在应答:标记在线,不占用"局域网发现"的记录,
                // 免得界面把公网服务器和局域网中转混成一个。
                st2->server_state = VT_SERVER_ONLINE;
                st2->server_last_rx = now;
            } else {
                st2->relay_seen = true;
                st2->relay_addr = src_addr;
                st2->relay_port = port ? port : VT_UDP_PORT;
            }
            app_state_unlock();
            ESP_LOGI(TAG, "发现中转服务器 %u.%u.%u.%u:%u",
                     (unsigned)(src_addr & 0xFF), (unsigned)((src_addr >> 8) & 0xFF),
                     (unsigned)((src_addr >> 16) & 0xFF), (unsigned)((src_addr >> 24) & 0xFF),
                     (unsigned)port);
        }
        break;
    }
    default:
        return;   // DISCOVER 是设备发的,服务器才需要处理
    }
}

static void sync_time_once(void) {
    if (s_time_requested) return;
    s_time_requested = true;
    // 国内可达性好的一组 NTP;失败也不影响通话,只是顶部时间显示 --:--
    sntp_setoperatingmode(SNTP_OPMODE_POLL);
    sntp_setservername(0, "ntp.aliyun.com");
    sntp_setservername(1, "pool.ntp.org");
    sntp_init();
    setenv("TZ", "CST-8", 1);   // 东八区,无夏令时
    tzset();
}

void app_net_sync_time(void) {
    s_time_requested = false;
    sync_time_once();
}

static void net_task(void *arg) {
    (void)arg;
    uint32_t last_hello = 0;
    uint32_t last_discover = 0;

    for (;;) {
        uint32_t now = (uint32_t)(xTaskGetTickCount() * portTICK_PERIOD_MS);

        app_state_lock();
        vt_link_state_t link = app_state()->link;
        bool has_wifi = app_state()->cfg.wifi_count > 0;
        app_state_unlock();

        if (!s_sta_ready && has_wifi) {
            s_sta_ready = true;
            connect_next_wifi();
        }
        // 断线重连:换下一个已保存的 Wi-Fi 再试。
        if (s_sta_ready && has_wifi && link == VT_LINK_DOWN && (now % 10000u) < VT_RX_TICK_MS) {
            s_wifi_try_index++;
            connect_next_wifi();
        }

        int sock = -1;
        if (link == VT_LINK_UP) {
            sock = ensure_socket();
            if (!s_time_requested) sync_time_once();
        }

        if (sock >= 0) {
            uint8_t buf[VT_HEADER_SIZE + VT_MAX_PAYLOAD + 32];
            struct sockaddr_in from;
            socklen_t from_len = sizeof(from);
            ssize_t n = recvfrom(sock, buf, sizeof(buf), 0,
                                 (struct sockaddr *)&from, &from_len);
            if (n > 0) {
                handle_packet(buf, (size_t)n, from.sin_addr.s_addr);
            }
        }

        if (link == VT_LINK_UP) {
            // 互联网服务器:解析域名 + 探活 + 超时判定。
            // 内部会阻塞做 DNS 查询,所以必须在网络任务里,不能在按键回调里。
            update_server(now);
            if (now - last_hello >= VT_HELLO_INTERVAL_MS) {
                last_hello = now;
                app_net_send_hello_now();
            }
            app_state_lock();
            uint8_t transport = app_state()->cfg.transport;
            bool relay = app_state()->relay_seen;
            uint32_t server_addr = app_state()->server_addr;
            app_state_unlock();
            // 只有"既没填服务器地址、也没在局域网发现中转"时才广播找服务器 ——
            // 填了地址的交给 update_server() 单播探活,广播在公网环境下到不了。
            if (transport == (uint8_t)VT_TRANSPORT_SERVER && !relay && server_addr == 0u &&
                now - last_discover >= VT_DISCOVER_INTERVAL_MS) {
                last_discover = now;
                int s = ensure_socket();
                if (s >= 0) {
                    send_packet(s, VT_PKT_DISCOVER, NULL, 0,
                                s_broadcast_addr ? s_broadcast_addr : htonl(INADDR_BROADCAST),
                                VT_UDP_PORT);
                }
            }
            // 成员过期 + 更新在线人数/当前发话者
            app_state_lock();
            app_state_t *st = app_state();
            vt_roster_expire(&st->roster, now);
            st->online = vt_roster_online(&st->roster);
            st->speaker_id = vt_roster_speaker(&st->roster, now);
            app_state_unlock();
        }

        vTaskDelay(pdMS_TO_TICKS(VT_RX_TICK_MS));
    }
}

esp_err_t app_net_start(void) {
    if (s_started) return ESP_OK;
    esp_err_t err = wifi_stack_start();
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Wi-Fi 启动失败: %s", esp_err_to_name(err));
        return err;
    }

    app_state_lock();
    if (app_state()->self_id == 0u) {
        uint16_t id = 0;
        while (id == 0u) id = (uint16_t)(esp_random() & 0xFFFFu);
        app_state()->self_id = id;
        app_state()->roster.self_id = id;
    }
    app_state_unlock();

    if (xTaskCreate(net_task, "vt_net", 4096, NULL, 5, &s_task) != pdPASS) {
        return ESP_ERR_NO_MEM;
    }
    s_started = true;
    return ESP_OK;
}

esp_err_t app_net_reconnect(void) {
    s_wifi_try_index = 0;
    s_sta_ready = false;
    app_state_lock();
    app_state()->link = VT_LINK_CONNECTING;
    app_state_unlock();
    s_sta_ready = true;
    connect_next_wifi();
    return ESP_OK;
}

bool app_net_ap_enabled(void) {
    app_state_lock();
    bool on = app_state()->ap_on;
    app_state_unlock();
    return on;
}

// 关机/重启前让同伴立刻把我们摘掉(能发出去就发,发不出去也不阻塞)。
void app_net_shutdown(void) {
    send_bye();
}

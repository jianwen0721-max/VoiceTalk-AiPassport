// main/app_storage.c —— 用 NVS 存配置。
#include "app_storage.h"

#include "app_config.h"

#include "esp_log.h"
#include "nvs.h"
#include "nvs_flash.h"

#include <string.h>

static const char *TAG = "vt_store";
static const char *NS = "vt";
static bool s_ready;

esp_err_t app_storage_init(void) {
    if (s_ready) return ESP_OK;
    // 分区表里 NVS 只有 24 KB;容量不够就整个重来一次(只清 NVS 分区,
    // 不动应用和 PHY 数据),比让每台机器都写不进配置要好。
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_LOGW(TAG, "NVS 分区需要重整: %s", esp_err_to_name(err));
        err = nvs_flash_erase();
        if (err != ESP_OK) return err;
        err = nvs_flash_init();
    }
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "NVS 初始化失败: %s", esp_err_to_name(err));
        return err;
    }
    s_ready = true;
    return ESP_OK;
}

static void load_string(nvs_handle_t h, const char *key, char *out, size_t cap,
                        const char *fallback) {
    size_t len = cap;
    esp_err_t err = nvs_get_str(h, key, out, &len);
    if (err != ESP_OK || len == 0 || len > cap) {
        strncpy(out, fallback ? fallback : "", cap - 1);
        out[cap - 1] = '\0';
    }
}

static void get_u8(nvs_handle_t h, const char *key, uint8_t *out, uint8_t fallback) {
    uint8_t v = 0;
    if (nvs_get_u8(h, key, &v) == ESP_OK) *out = v;
    else *out = fallback;
}

esp_err_t app_storage_load(vt_config_t *out) {
    if (!out) return ESP_ERR_INVALID_ARG;
    vt_config_defaults(out);
    if (!s_ready) return ESP_ERR_INVALID_STATE;

    nvs_handle_t h;
    esp_err_t err = nvs_open(NS, NVS_READONLY, &h);
    if (err == ESP_ERR_NVS_NOT_FOUND) return ESP_OK;   // 首次开机:用默认值
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "打开 NVS 命名空间失败: %s", esp_err_to_name(err));
        return err;
    }

    load_string(h, "name", out->name, sizeof(out->name), "");

    uint32_t room = 0;
    if (nvs_get_u32(h, "room", &room) == ESP_OK) out->room = room;

    uint16_t pass = 0;
    if (nvs_get_u16(h, "pass", &pass) == ESP_OK) out->passcode = pass;

    uint8_t u8 = 0;
    get_u8(h, "haspass", &u8, 0);
    out->has_pass = u8 != 0;
    get_u8(h, "vol", &out->volume, out->volume);
    get_u8(h, "bri", &out->brightness, out->brightness);
    get_u8(h, "tran", &out->transport, out->transport);
    get_u8(h, "wificnt", &u8, 0);
    out->wifi_count = u8 > VT_WIFI_MAX ? VT_WIFI_MAX : u8;

    for (uint8_t i = 0; i < out->wifi_count; i++) {
        char ks[10], kp[10];
        snprintf(ks, sizeof(ks), "w%us", (unsigned)i);
        snprintf(kp, sizeof(kp), "w%up", (unsigned)i);
        load_string(h, ks, out->wifi[i].ssid, sizeof(out->wifi[i].ssid), "");
        load_string(h, kp, out->wifi[i].pass, sizeof(out->wifi[i].pass), "");
    }

    load_string(h, "srvh", out->server_host, sizeof(out->server_host), "");
    uint16_t srvport = 0;
    if (nvs_get_u16(h, "srvpt", &srvport) == ESP_OK) out->server_port = srvport;

    nvs_close(h);
    vt_config_sanitize(out);
    return ESP_OK;
}

esp_err_t app_storage_save(const vt_config_t *in) {
    if (!in || !s_ready) return ESP_ERR_INVALID_STATE;

    vt_config_t cfg = *in;
    vt_config_sanitize(&cfg);

    nvs_handle_t h;
    esp_err_t err = nvs_open(NS, NVS_READWRITE, &h);
    if (err != ESP_OK) return err;

#define TRY(x) do { err = (x); if (err != ESP_OK) goto done; } while (0)
    TRY(nvs_set_str(h, "name", cfg.name));
    TRY(nvs_set_u32(h, "room", cfg.room));
    TRY(nvs_set_u16(h, "pass", cfg.passcode));
    TRY(nvs_set_u8(h, "haspass", cfg.has_pass ? 1 : 0));
    TRY(nvs_set_u8(h, "vol", cfg.volume));
    TRY(nvs_set_u8(h, "bri", cfg.brightness));
    TRY(nvs_set_u8(h, "tran", cfg.transport));
    TRY(nvs_set_u8(h, "wificnt", cfg.wifi_count));
    for (uint8_t i = 0; i < cfg.wifi_count; i++) {
        char ks[10], kp[10];
        snprintf(ks, sizeof(ks), "w%us", (unsigned)i);
        snprintf(kp, sizeof(kp), "w%up", (unsigned)i);
        TRY(nvs_set_str(h, ks, cfg.wifi[i].ssid));
        TRY(nvs_set_str(h, kp, cfg.wifi[i].pass));
    }
    TRY(nvs_set_str(h, "srvh", cfg.server_host));
    TRY(nvs_set_u16(h, "srvpt", cfg.server_port));
    TRY(nvs_commit(h));
#undef TRY

done:
    nvs_close(h);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "保存配置失败: %s", esp_err_to_name(err));
    }
    return err;
}

esp_err_t app_storage_reset(void) {
    if (!s_ready) return ESP_ERR_INVALID_STATE;
    nvs_handle_t h;
    esp_err_t err = nvs_open(NS, NVS_READWRITE, &h);
    if (err == ESP_ERR_NVS_NOT_FOUND) return ESP_OK;   // 本来就没存过
    if (err != ESP_OK) return err;
    err = nvs_erase_all(h);
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);
    return err;
}

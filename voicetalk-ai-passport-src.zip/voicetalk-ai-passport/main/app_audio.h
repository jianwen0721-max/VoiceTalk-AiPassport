// main/app_audio.h —— 半双工对讲音频:按住 OK 录音发送,收到同伴语音就播放。
//
// 半双工是刻意的:对讲机不回声、不啸叫;发话期间不播放别人的语音
// (同一时刻只允许一个发话者),松手或收到 AUDIO_END 立刻停播。
#pragma once

#include <stdbool.h>
#include <stdint.h>

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

// 启动音频任务与 ES8311。音量与格式在内部按配置设置。
esp_err_t app_audio_start(uint8_t volume_percent);

// 开始/结束发话(PTT)。重复调用安全。
void app_audio_start_tx(void);
void app_audio_stop_tx(void);
bool app_audio_is_tx(void);

// 网络任务收到一帧语音时投递给播放端。缓冲满时丢最旧的一帧 ——
// 对讲要的是"现在在说什么",宁可丢帧也不要累积延迟。
bool app_audio_submit_rx(const uint8_t *frame, uint16_t len);

// 通知播放端"发话结束"(收到 AUDIO_END)。
void app_audio_rx_end(void);

// 最近一帧的电平 0..100(发话时取麦克风,否则取正在播放的那一帧)。
// 只用来画界面上的电平条,不是仪表级测量;超过 600 ms 没有新帧就回到 0。
uint8_t app_audio_level(void);

// 音量 0..100,立即生效(网页和设置页都走这里)。
void app_audio_set_volume(uint8_t percent);

#ifdef __cplusplus
}
#endif

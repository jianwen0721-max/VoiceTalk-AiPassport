#!/usr/bin/env python3
"""Every Chinese character shown on screen must exist in the generated font subset.

默认 Montserrat 一个汉字都没有,界面上凡是漏进字库的汉字都会显示成空白或
方框,而且只有把固件烧到屏上才看得出来 —— 所以在这里就把它挡住。
"""

from __future__ import annotations

import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SYMBOLS = ROOT / "assets" / "fonts" / "app_font_symbols.txt"
FONT_C = ROOT / "assets" / "fonts" / "app_font_16.c"
UI_C = ROOT / "main" / "app_ui.c"

# 只关心可能出现汉字的区间:CJK 部首/ext A/汉字/兼容汉字/全角与标点。
CJK_START = 0x2E80


def strip_comments(text: str) -> str:
    out = []
    i = 0
    n = len(text)
    while i < n:
        c = text[i]
        if c == '/' and i + 1 < n and text[i + 1] == '/':
            i += 2
            while i < n and text[i] != '\n':
                i += 1
        elif c == '/' and i + 1 < n and text[i + 1] == '*':
            i += 2
            while i + 1 < n and not (text[i] == '*' and text[i + 1] == '/'):
                i += 1
            i += 2
        else:
            out.append(c)
            i += 1
    return "".join(out)


def string_literals(text: str) -> list[str]:
    """取出 C 代码里的双引号字符串(注释已在外面剥掉)。"""
    lits = []
    i = 0
    n = len(text)
    while i < n:
        if text[i] != '"':
            i += 1
            continue
        i += 1
        buf = []
        while i < n:
            c = text[i]
            if c == '\\' and i + 1 < n:
                buf.append(text[i + 1])
                i += 2
                continue
            if c == '"':
                break
            buf.append(c)
            i += 1
        i += 1
        lits.append("".join(buf))
    return lits


def wide_chars(text: str) -> set[str]:
    return {ch for ch in text if ord(ch) >= CJK_START}


class FontCoverageTest(unittest.TestCase):
    def covered_from_generated_font(self) -> set[str]:
        """以真正编译进固件的那份 .c 为准(lv_font_conv 会把 --symbols 写进头注释)。"""
        head = FONT_C.read_text(encoding="utf-8")[:65536]
        match = re.search(r"--symbols\s+(.*?)\s+--size\s", head, re.DOTALL)
        self.assertIsNotNone(match, f"{FONT_C.name} 头部找不到 --symbols,无法确认字库内容")
        assert match is not None
        return wide_chars(match.group(1))

    def test_symbols_file_matches_generated_font(self) -> None:
        covered = self.covered_from_generated_font()
        listed = wide_chars(SYMBOLS.read_text(encoding="utf-8"))
        self.assertTrue(listed, "字符清单是空的")
        missing = sorted(listed - covered)
        self.assertEqual(missing, [],
                         f"字库清单里有 {len(missing)} 个字符没进生成的字体: {missing[:20]}")

    def test_interface_strings_are_all_in_font(self) -> None:
        covered = self.covered_from_generated_font()
        missing: dict[str, set[str]] = {}
        # 只查真的会画到屏上的那一份:app_web.c 的中文是给手机浏览器看的,
        # app_net.c 等里的中文只在串口日志里,都不经过这个字库。
        for path in [UI_C]:
            text = strip_comments(path.read_text(encoding="utf-8"))
            used = set()
            for lit in string_literals(text):
                used |= wide_chars(lit)
            gap = used - covered
            if gap:
                missing[path.name] = gap
        self.assertEqual(
            missing, {},
            "界面里有字符不在字库内(刷到屏上会显示成空白/方框): "
            + "; ".join(f"{name}: {sorted(chars)}" for name, chars in missing.items())
            + "。请把这些字加进 tools/gen_app_font_symbols.py 的字符清单并重新生成字体。")

    def test_ui_declares_and_uses_the_chinese_font(self) -> None:
        source = UI_C.read_text(encoding="utf-8")
        self.assertIn("LV_FONT_DECLARE(app_font_16)", source)
        # 中文字号必须显式指定:漏一处就会退回 Montserrat,汉字全变方框。
        self.assertRegex(source, r"mk_label\([^;]*&app_font_16")


if __name__ == "__main__":
    unittest.main()

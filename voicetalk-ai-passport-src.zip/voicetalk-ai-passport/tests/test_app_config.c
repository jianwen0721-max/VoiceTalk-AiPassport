// tests/test_app_config.c —— 配置默认值、钳制与校验的主机端测试。
#include "app_config.h"

#include <stdio.h>
#include <string.h>

static int failures;

#define CHECK(cond) do {                                        \
    if (!(cond)) {                                              \
        printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond);  \
        failures++;                                             \
    }                                                           \
} while (0)

static void test_defaults(void) {
    vt_config_t cfg;
    vt_config_defaults(&cfg);
    CHECK(cfg.name[0] == '\0');
    CHECK(cfg.room == 0u);
    CHECK(!cfg.has_pass);
    CHECK(cfg.volume == 70u);
    CHECK(cfg.brightness == 80u);
    CHECK(cfg.transport == (uint8_t)VT_TRANSPORT_LAN);
    CHECK(cfg.wifi_count == 0u);
    // 默认不指定服务器:与加这个字段之前一样,只用局域网广播发现
    CHECK(cfg.server_host[0] == '\0');
    CHECK(cfg.server_port == VT_SERVER_PORT_DEFAULT);
}

static void test_sanitize(void) {
    vt_config_t cfg;
    vt_config_defaults(&cfg);
    // 模拟 NVS 里的脏数据
    cfg.volume = 200u;
    cfg.brightness = 0u;
    cfg.room = VT_ROOM_MAX + 1u;
    cfg.transport = 9u;
    cfg.has_pass = true;
    cfg.passcode = 60000u;      // 超过 4 位密码上限(9999)
    strncpy(cfg.name, "坏\n名字", sizeof(cfg.name));

    vt_config_sanitize(&cfg);
    CHECK(cfg.volume <= VT_VOLUME_MAX);
    CHECK(cfg.brightness >= VT_BRIGHTNESS_MIN);
    CHECK(cfg.room <= VT_ROOM_MAX);
    CHECK(cfg.transport == (uint8_t)VT_TRANSPORT_LAN);
    CHECK(cfg.passcode == 0u);
    CHECK(cfg.name[0] == '\0');      // 含控制字符的名字被丢弃

    // 合法中文名要保留
    vt_config_defaults(&cfg);
    strncpy(cfg.name, "张三", sizeof(cfg.name));
    vt_config_sanitize(&cfg);
    CHECK(strcmp(cfg.name, "张三") == 0);
}

static void test_wifi_list(void) {
    vt_config_t cfg;
    vt_config_defaults(&cfg);

    CHECK(vt_config_wifi_add(&cfg, "Home", "12345678"));
    CHECK(vt_config_wifi_add(&cfg, "Office", "87654321"));
    CHECK(cfg.wifi_count == 2u);
    CHECK(strcmp(cfg.wifi[0].ssid, "Home") == 0);

    // 同名覆盖
    CHECK(vt_config_wifi_add(&cfg, "Home", "newpass1"));
    CHECK(cfg.wifi_count == 2u);
    CHECK(strcmp(cfg.wifi[0].pass, "newpass1") == 0);

    // 开放网络(空密码)允许;空 SSID 拒绝
    CHECK(vt_config_wifi_add(&cfg, "OpenNet", ""));
    CHECK(!vt_config_wifi_add(&cfg, "", "12345678"));
    // 太短的密码拒绝(WPA2 最短 8 位)
    CHECK(!vt_config_wifi_add(&cfg, "Short", "123"));

    for (uint8_t i = cfg.wifi_count; i < VT_WIFI_MAX; i++) {
        char ssid[8];
        snprintf(ssid, sizeof(ssid), "N%u", (unsigned)i);
        CHECK(vt_config_wifi_add(&cfg, ssid, "12345678"));
    }
    CHECK(cfg.wifi_count == VT_WIFI_MAX);
    CHECK(!vt_config_wifi_add(&cfg, "Overflow", "12345678"));   // 满 5 条

    CHECK(vt_config_wifi_find(&cfg, "Office") == 1);
    CHECK(vt_config_wifi_find(&cfg, "None") == -1);
    CHECK(vt_config_wifi_remove(&cfg, 1));
    CHECK(cfg.wifi_count == VT_WIFI_MAX - 1u);
    CHECK(vt_config_wifi_find(&cfg, "Office") == -1);
    CHECK(!vt_config_wifi_remove(&cfg, 99));
}

static void test_field_checks(void) {
    uint32_t room = 0;
    uint16_t code = 0;
    bool has = false;

    CHECK(vt_config_check_name("Fox"));
    CHECK(vt_config_check_name("张三"));
    CHECK(!vt_config_check_name(""));
    CHECK(!vt_config_check_name("   "));

    CHECK(vt_config_check_room("000123", &room) && room == 123u);
    CHECK(!vt_config_check_room("123", &room));
    CHECK(!vt_config_check_room("abcdef", &room));

    CHECK(vt_config_check_pass("", &code, &has) && !has && code == 0u);
    CHECK(vt_config_check_pass("0042", &code, &has) && has && code == 42u);
    CHECK(!vt_config_check_pass("42", &code, &has));
    CHECK(!vt_config_check_pass("42a1", &code, &has));
}

static void test_server_checks(void) {
    uint16_t port = 0;

    // 空地址合法 —— 表示"不指定服务器",设备退回局域网广播发现。
    CHECK(vt_config_check_host(""));
    CHECK(vt_config_check_port("", &port) && port == VT_SERVER_PORT_DEFAULT);

    // IPv4 字面量与常见域名(含 DDNS)
    CHECK(vt_config_check_host("203.0.113.7"));
    CHECK(vt_config_check_host("192.168.1.1"));
    CHECK(vt_config_check_host("voice.example.com"));
    CHECK(vt_config_check_host("my-relay_1.ddns.net"));
    CHECK(vt_config_check_host("a"));

    // 形状不合法
    CHECK(!vt_config_check_host("-lead.example.com"));   // 连字符开头
    CHECK(!vt_config_check_host("trail-.example.com"));  // 标签以连字符结尾
    CHECK(!vt_config_check_host("tail.example.com."));   // 以点结尾(空标签)
    CHECK(!vt_config_check_host("dou..ble.com"));        // 连续两个点
    CHECK(!vt_config_check_host("has space.com"));
    CHECK(!vt_config_check_host("http://example.com"));  // 不要带协议头
    CHECK(!vt_config_check_host("example.com:8801"));    // 端口单独一个字段
    CHECK(!vt_config_check_host(NULL));

    // 长度边界:正好 64 字节收下,超长拒掉(否则会越过定长缓冲)
    char host[VT_SERVER_HOST_MAX + 1];
    memset(host, 'a', sizeof(host) - 1u);
    host[sizeof(host) - 1u] = '\0';
    CHECK(strlen(host) == VT_SERVER_HOST_MAX);
    CHECK(vt_config_check_host(host));
    char too_long[VT_SERVER_HOST_MAX + 2];
    memset(too_long, 'a', sizeof(too_long) - 1u);
    too_long[sizeof(too_long) - 1u] = '\0';
    CHECK(!vt_config_check_host(too_long));

    // 端口
    CHECK(vt_config_check_port("8801", &port) && port == 8801u);
    CHECK(vt_config_check_port("65535", &port) && port == 65535u);
    CHECK(vt_config_check_port("1", &port) && port == 1u);
    CHECK(!vt_config_check_port("0", &port));
    CHECK(!vt_config_check_port("65536", &port));
    CHECK(!vt_config_check_port("99999", &port));
    CHECK(!vt_config_check_port("88a1", &port));
    CHECK(!vt_config_check_port(" 8801", &port));
    CHECK(!vt_config_check_port("0x2261", &port));
    CHECK(!vt_config_check_port(NULL, &port));

    // sanitize:非法地址整条清掉,端口越界回默认 —— 留一个解析不出的地址
    // 只会让设备卡在"寻找中",清掉反而能看到真实状态。
    vt_config_t cfg;
    vt_config_defaults(&cfg);
    strncpy(cfg.server_host, "bad host!", sizeof(cfg.server_host) - 1u);
    cfg.server_port = 0u;
    vt_config_sanitize(&cfg);
    CHECK(cfg.server_host[0] == '\0');
    CHECK(cfg.server_port == VT_SERVER_PORT_DEFAULT);

    vt_config_defaults(&cfg);
    strncpy(cfg.server_host, "voice.example.com", sizeof(cfg.server_host) - 1u);
    cfg.server_port = 9000u;
    vt_config_sanitize(&cfg);
    CHECK(strcmp(cfg.server_host, "voice.example.com") == 0);
    CHECK(cfg.server_port == 9000u);
}

int main(void) {
    test_defaults();
    test_sanitize();
    test_wifi_list();
    test_field_checks();
    test_server_checks();
    if (failures) {
        printf("test_app_config: %d 项失败\n", failures);
        return 1;
    }
    printf("test_app_config: PASS\n");
    return 0;
}

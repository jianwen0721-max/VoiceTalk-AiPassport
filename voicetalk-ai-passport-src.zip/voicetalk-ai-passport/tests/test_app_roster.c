// tests/test_app_roster.c —— 房间成员表的主机端测试。
#include "app_roster.h"

#include <stdio.h>
#include <string.h>

static int failures;

#define CHECK(cond) do {                                        \
    if (!(cond)) {                                              \
        printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond);  \
        failures++;                                             \
    }                                                           \
} while (0)

static void test_basic(void) {
    vt_roster_t roster;
    vt_roster_init(&roster, 0x00A1u);

    CHECK(vt_roster_count(&roster) == 0u);
    CHECK(vt_roster_online(&roster) == 1u);      // 只有自己

    CHECK(vt_roster_upsert(&roster, 0x00B2u, "张三", 1000u));
    CHECK(vt_roster_upsert(&roster, 0x00C3u, "李四", 1000u));
    CHECK(vt_roster_count(&roster) == 2u);
    CHECK(vt_roster_online(&roster) == 3u);
    CHECK(strcmp(vt_roster_name(&roster, 0x00B2u), "张三") == 0);
    CHECK(vt_roster_name(&roster, 0xFFFFu) == NULL);

    // 同名 sender 再上报 = 刷新,不是新增
    CHECK(vt_roster_upsert(&roster, 0x00B2u, "张三丰", 2000u));
    CHECK(vt_roster_count(&roster) == 2u);
    CHECK(strcmp(vt_roster_name(&roster, 0x00B2u), "张三丰") == 0);

    // 自己不该进表
    CHECK(!vt_roster_upsert(&roster, 0x00A1u, "我自己", 1000u));
    CHECK(!vt_roster_upsert(&roster, 0u, "空 id", 1000u));
    CHECK(vt_roster_count(&roster) == 2u);

    CHECK(vt_roster_remove(&roster, 0x00B2u));
    CHECK(!vt_roster_remove(&roster, 0x00B2u));
    CHECK(vt_roster_count(&roster) == 1u);

    vt_roster_clear(&roster);
    CHECK(vt_roster_count(&roster) == 0u);
    CHECK(roster.self_id == 0x00A1u);           // clear 保留 self_id
}

static void test_expire(void) {
    vt_roster_t roster;
    vt_roster_init(&roster, 0x1111u);

    vt_roster_upsert(&roster, 0x0002u, "甲", 0u);
    vt_roster_upsert(&roster, 0x0003u, "乙", 1000u);

    CHECK(vt_roster_expire(&roster, 1000u) == 0u);            // 都还活着
    CHECK(vt_roster_expire(&roster, VT_MEMBER_TTL_MS + 1u) == 1u);
    CHECK(vt_roster_count(&roster) == 1u);
    CHECK(vt_roster_expire(&roster, VT_MEMBER_TTL_MS + 1001u) == 1u);
    CHECK(vt_roster_count(&roster) == 0u);
}

static void test_capacity(void) {
    vt_roster_t roster;
    vt_roster_init(&roster, 0x2222u);

    char name[16];
    for (uint32_t i = 1; i <= VT_ROOM_MAX_MEMBERS; i++) {
        snprintf(name, sizeof(name), "M%u", (unsigned)i);
        CHECK(vt_roster_upsert(&roster, (uint16_t)(0x1000u + i), name, 0u));
    }
    CHECK(vt_roster_count(&roster) == VT_ROOM_MAX_MEMBERS);
    CHECK(vt_roster_online(&roster) == VT_ROOM_MAX_MEMBERS);   // 含自己,封顶 32

    // 满员后不再接收新成员(先到先得,不挤掉正在说话的人)
    CHECK(!vt_roster_upsert(&roster, 0x9999u, "第33人", 0u));
    CHECK(vt_roster_count(&roster) == VT_ROOM_MAX_MEMBERS);
}

static void test_speaker(void) {
    vt_roster_t roster;
    vt_roster_init(&roster, 0x3333u);

    CHECK(vt_roster_speaker(&roster, 0u) == 0u);

    vt_roster_upsert(&roster, 0x0004u, "王五", 0u);
    vt_roster_note_audio(&roster, 0x0004u, 1000u);
    CHECK(vt_roster_speaker(&roster, 1000u) == 0x0004u);
    CHECK(vt_roster_speaker(&roster, 1500u) == 0x0004u);
    // 超过保持时间没有新语音 → 视为说完
    CHECK(vt_roster_speaker(&roster, 1000u + VT_SPEAKER_HOLD_MS + 1u) == 0u);

    vt_roster_note_audio(&roster, 0x0004u, 2000u);
    vt_roster_end_audio(&roster, 0x0004u);
    CHECK(vt_roster_speaker(&roster, 2000u) == 0u);

    // 自己的语音不记成"别人在发话"
    vt_roster_note_audio(&roster, 0x3333u, 3000u);
    CHECK(vt_roster_speaker(&roster, 3000u) == 0u);
}

int main(void) {
    test_basic();
    test_expire();
    test_capacity();
    test_speaker();
    if (failures) {
        printf("test_app_roster: %d 项失败\n", failures);
        return 1;
    }
    printf("test_app_roster: PASS\n");
    return 0;
}

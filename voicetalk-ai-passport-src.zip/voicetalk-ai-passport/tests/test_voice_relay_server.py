#!/usr/bin/env python3
"""Check the UDP relay server: key parity with the firmware and end-to-end relaying."""

from __future__ import annotations

import importlib.util
import socket
import subprocess
import sys
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RELAY = ROOT / "tools" / "voice_relay_server.py"

# 这些值由 main/app_protocol.c 的 vt_room_key() 打印出来抄在这里:中转服务器
# 算出的密钥必须和固件逐位一致,否则密码正确的设备会被当成密码错误拒掉。
FIRMWARE_KEYS = {
    (0, 0): 303091727,
    (0, 1): 3960362406,
    (0, 2580): 333395561,
    (0, 9999): 521347869,
    (1, 0): 3412691020,
    (1, 1): 4050387637,
    (1, 2580): 2374450118,
    (1, 9999): 2589160666,
    (123456, 0): 2576831554,
    (123456, 1): 3214528171,
    (123456, 2580): 3615072456,
    (123456, 9999): 1421000224,
    (999999, 0): 3585661081,
    (999999, 1): 2947964464,
    (999999, 2580): 60492783,
    (999999, 9999): 3872999175,
}


def load_relay():
    spec = importlib.util.spec_from_file_location("voice_relay_server", RELAY)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def header(pkt_type: int, room: int, sender: int, seq: int, flags: int,
           payload: bytes = b"") -> bytes:
    out = bytes([0x56, 0x54, 2, pkt_type])
    out += room.to_bytes(4, "big")
    out += sender.to_bytes(2, "big")
    out += seq.to_bytes(2, "big")
    out += len(payload).to_bytes(2, "big")
    out += flags.to_bytes(2, "big")
    return out + payload


def hello(room: int, sender: int, name: str, key: int) -> bytes:
    raw = name.encode("utf-8")
    return header(1, room, sender, 0, 0, bytes([len(raw)]) + raw + key.to_bytes(4, "big"))


def free_udp_port() -> int:
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    probe.bind(("127.0.0.1", 0))
    port = probe.getsockname()[1]
    probe.close()
    return int(port)


class RelayKeyTest(unittest.TestCase):
    def test_room_key_matches_firmware(self) -> None:
        relay = load_relay()
        for (room, passcode), expected in FIRMWARE_KEYS.items():
            with self.subTest(room=room, passcode=passcode):
                self.assertEqual(relay.room_key(room, passcode, True), expected)

    def test_room_without_password_has_no_key(self) -> None:
        relay = load_relay()
        self.assertEqual(relay.room_key(123456, 2580, False), 0)

    def test_header_layout_matches_protocol(self) -> None:
        relay = load_relay()
        buf = relay.encode(relay.PKT_SERVER_HERE, 123456, 0, 0, 0, (8801).to_bytes(2, "big"))
        self.assertEqual(len(buf), relay.HEADER_SIZE + 2)
        parsed = relay.decode(buf)
        self.assertIsNotNone(parsed)
        assert parsed is not None
        pkt_type, room, sender, seq, length, flags = parsed
        self.assertEqual((pkt_type, room, sender, seq, length, flags),
                         (relay.PKT_SERVER_HERE, 123456, 0, 0, 2, 0))
        self.assertEqual(relay.decode(b"XX" + buf[2:]), None)   # magic 不对
        self.assertEqual(relay.decode(buf[:15]), None)          # 短包


class RelayEndToEndTest(unittest.TestCase):
    def test_relays_audio_between_two_clients(self) -> None:
        relay = load_relay()
        port = free_udp_port()
        room = 123456
        key = relay.room_key(room, 2580, True)
        proc = subprocess.Popen(
            [sys.executable, str(RELAY), "--host", "127.0.0.1", "--port", str(port),
             "--room", str(room), "--passcode", "2580"],
            cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            deadline = time.monotonic() + 10.0
            while time.monotonic() < deadline:
                try:
                    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                    probe.settimeout(0.3)
                    probe.sendto(header(5, room, 0, 0, 0), ("127.0.0.1", port))
                    data, _ = probe.recvfrom(64)
                    probe.close()
                    if data[3] == relay.PKT_SERVER_HERE:
                        break
                except OSError:
                    probe.close()
                    time.sleep(0.1)
            else:
                self.fail("服务器没有应答 DISCOVER")

            talker = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            listener = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.addCleanup(talker.close)
            self.addCleanup(listener.close)
            talker.bind(("127.0.0.1", 0))
            listener.bind(("127.0.0.1", 0))
            talker.settimeout(2.0)
            listener.settimeout(2.0)
            server = ("127.0.0.1", port)

            talker.sendto(hello(room, 0x1111, "甲", key), server)
            listener.sendto(hello(room, 0x2222, "乙", key), server)
            time.sleep(0.2)
            talker.sendto(header(3, room, 0x1111, 1, 1, b"\x11" * 320), server)
            data, _ = listener.recvfrom(512)
            self.assertEqual(data[3], relay.PKT_AUDIO)
            self.assertEqual(len(data), relay.HEADER_SIZE + 320)
            self.assertEqual(data[8:10], (0x1111).to_bytes(2, "big"))

            # 说话的人自己不该收到自己的回声
            talker.settimeout(0.4)
            with self.assertRaises(socket.timeout):
                talker.recvfrom(512)
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=5)

    def test_rejects_clients_with_wrong_passcode(self) -> None:
        relay = load_relay()
        port = free_udp_port()
        room = 654321
        good = relay.room_key(room, 2580, True)
        wrong = relay.room_key(room, 9999, True)
        self.assertNotEqual(good, wrong)
        proc = subprocess.Popen(
            [sys.executable, str(RELAY), "--host", "127.0.0.1", "--port", str(port),
             "--passcode", "2580"],
            cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            time.sleep(1.0)
            member = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            stranger = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.addCleanup(member.close)
            self.addCleanup(stranger.close)
            member.bind(("127.0.0.1", 0))
            stranger.bind(("127.0.0.1", 0))
            member.settimeout(2.0)
            stranger.settimeout(0.6)
            server = ("127.0.0.1", port)
            member.sendto(hello(room, 0x1111, "甲", good), server)
            stranger.sendto(hello(room, 0x2222, "乙", wrong), server)
            time.sleep(0.2)
            # 密码不对的人既进不了房间,也不能往房间里灌声音
            stranger.sendto(header(3, room, 0x2222, 1, 1, b"\x22" * 320), server)
            with self.assertRaises(socket.timeout):
                member.recvfrom(512)
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=5)


if __name__ == "__main__":
    unittest.main()

// tests/test_app_protocol.c —— 线路协议的主机端测试(不依赖 ESP-IDF / LVGL)。
#include "app_protocol.h"

#include <stdio.h>
#include <string.h>

static int failures;

#define CHECK(cond) do {                                        \
    if (!(cond)) {                                              \
        printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond);  \
        failures++;                                             \
    }                                                           \
} while (0)

static void test_room_and_pass(void) {
    uint32_t room = 0;
    CHECK(vt_parse_room("000000", &room) && room == 0u);
    CHECK(vt_parse_room("123456", &room) && room == 123456u);
    CHECK(vt_parse_room("999999", &room) && room == 999999u);
    CHECK(!vt_parse_room("12345", &room));      // 不足 6 位
    CHECK(!vt_parse_room("1234567", &room));    // 超过 6 位
    CHECK(!vt_parse_room("12345a", &room));     // 非数字
    CHECK(!vt_parse_room("", &room));

    char text[VT_ROOM_DIGITS + 1];
    vt_format_room(0u, text);
    CHECK(strcmp(text, "000000") == 0);
    vt_format_room(7u, text);
    CHECK(strcmp(text, "000007") == 0);
    vt_format_room(999999u, text);
    CHECK(strcmp(text, "999999") == 0);

    uint16_t code = 0;
    CHECK(vt_parse_passcode("0000", &code) && code == 0u);
    CHECK(vt_parse_passcode("8311", &code) && code == 8311u);
    CHECK(!vt_parse_passcode("831", &code));
    CHECK(!vt_parse_passcode("83110", &code));
    CHECK(!vt_parse_passcode("83a1", &code));
}

static void test_name(void) {
    CHECK(vt_validate_name("Fox", 3));
    CHECK(vt_validate_name("张三", strlen("张三")));      // 汉字
    CHECK(vt_validate_name("A1 中", strlen("A1 中")));    // 混排
    CHECK(!vt_validate_name("", 0));                      // 空
    CHECK(!vt_validate_name("   ", 3));                   // 纯空格
    CHECK(!vt_validate_name("abc\n", 4));                 // 控制字符
    CHECK(!vt_validate_name("名字名字名字名字名字名字名字",
                            strlen("名字名字名字名字名字名字名字")));  // 超长(21 字节)

    CHECK(vt_utf8_length("abc", 3) == 3);
    CHECK(vt_utf8_length("中文", strlen("中文")) == 2);
    // 截断的多字节序列必须判为非法,否则屏幕上会出现乱码
    const char truncated[] = { 'a', (char)0xE4, (char)0xB8 };
    CHECK(vt_utf8_length(truncated, sizeof(truncated)) == -1);
    const char surrogate[] = { (char)0xED, (char)0xA0, (char)0x80 };
    CHECK(vt_utf8_length(surrogate, sizeof(surrogate)) == -1);
}

static void test_packet(void) {
    uint8_t buf[VT_HEADER_SIZE + VT_MAX_PAYLOAD];
    uint8_t payload[4] = { 0xDE, 0xAD, 0xBE, 0xEF };

    size_t n = vt_encode(buf, sizeof(buf), VT_PKT_HELLO, 123456u, 0x1234u, 7u, 0u,
                         payload, sizeof(payload));
    CHECK(n == VT_HEADER_SIZE + sizeof(payload));

    vt_packet_t pkt;
    CHECK(vt_decode(buf, n, &pkt));
    CHECK(pkt.type == VT_PKT_HELLO);
    CHECK(pkt.room == 123456u);
    CHECK(pkt.sender == 0x1234u);
    CHECK(pkt.seq == 7u);
    CHECK(pkt.payload_len == 4u);
    CHECK(pkt.payload && memcmp(pkt.payload, payload, 4) == 0);

    // 坏包:魔数错、版本错、长度不足、载荷长度与实际不符
    uint8_t bad[VT_HEADER_SIZE + 4];
    memcpy(bad, buf, sizeof(bad));
    bad[0] = 0x00;
    CHECK(!vt_decode(bad, sizeof(bad), &pkt));
    memcpy(bad, buf, sizeof(bad));
    bad[2] = 99;
    CHECK(!vt_decode(bad, sizeof(bad), &pkt));
    CHECK(!vt_decode(buf, VT_HEADER_SIZE - 1, &pkt));
    CHECK(!vt_decode(buf, VT_HEADER_SIZE + 2, &pkt));   // 声明 4 字节却只给了 2

    // 房号越界
    CHECK(vt_encode(buf, sizeof(buf), VT_PKT_BYE, VT_ROOM_MAX + 1u, 1u, 0u, 0u, NULL, 0) == 0);
    // 缓冲太小
    CHECK(vt_encode(buf, VT_HEADER_SIZE - 1, VT_PKT_BYE, 1u, 1u, 0u, 0u, NULL, 0) == 0);
    // 载荷超限
    CHECK(vt_encode(buf, sizeof(buf), VT_PKT_AUDIO, 1u, 1u, 0u, 0u, payload,
                    VT_MAX_PAYLOAD + 1u) == 0);
}

static void test_hello_payload(void) {
    uint8_t payload[1 + VT_NAME_MAX_BYTES + 4];
    size_t n = vt_encode_hello(payload, sizeof(payload), "张三", 0x11223344u);
    CHECK(n == 1u + strlen("张三") + 4u);
    CHECK(payload[0] == (uint8_t)strlen("张三"));

    char name[VT_NAME_MAX_BYTES + 1];
    uint32_t key = 0;
    CHECK(vt_decode_hello(payload, (uint16_t)n, name, sizeof(name), &key));
    CHECK(strcmp(name, "张三") == 0);
    CHECK(key == 0x11223344u);

    // 空名字 / 非法名字不能编码
    CHECK(vt_encode_hello(payload, sizeof(payload), "", 0u) == 0);
    CHECK(vt_encode_hello(payload, sizeof(payload), "a\nb", 0u) == 0);

    // 长度字段与实际不符
    CHECK(!vt_decode_hello(payload, 3u, name, sizeof(name), &key));
}

static void test_key_and_scramble(void) {
    // 无密码房间的密钥必须是 0(0 表示"不加密")
    CHECK(vt_room_key(123456u, 0u, false) == 0u);
    uint32_t k1 = vt_room_key(123456u, 1234u, true);
    uint32_t k2 = vt_room_key(123456u, 1235u, true);
    uint32_t k3 = vt_room_key(654321u, 1234u, true);
    CHECK(k1 != 0u && k1 != k2 && k1 != k3);
    // 同输入必须得到同输出(中转服务器是 Python,也要算得出一样的值)
    CHECK(k1 == vt_room_key(123456u, 1234u, true));

    uint8_t data[VT_AUDIO_FRAME_BYTES];
    uint8_t copy[VT_AUDIO_FRAME_BYTES];
    for (size_t i = 0; i < sizeof(data); i++) data[i] = (uint8_t)(i * 7u);
    memcpy(copy, data, sizeof(data));

    vt_scramble(data, sizeof(data), k1, 1u);
    CHECK(memcmp(data, copy, sizeof(data)) != 0);          // 确实变了
    vt_scramble(data, sizeof(data), k1, 1u);
    CHECK(memcmp(data, copy, sizeof(data)) == 0);          // 同一 seq 可逆

    // 不同 seq 的密文不同(防同一段静音每帧都一样)
    memcpy(data, copy, sizeof(data));
    vt_scramble(data, sizeof(data), k1, 2u);
    uint8_t other[VT_AUDIO_FRAME_BYTES];
    memcpy(other, copy, sizeof(other));
    vt_scramble(other, sizeof(other), k1, 3u);
    CHECK(memcmp(data, other, sizeof(data)) != 0);

    // 密钥为 0 时不改动数据(开放房间)
    memcpy(data, copy, sizeof(data));
    vt_scramble(data, sizeof(data), 0u, 1u);
    CHECK(memcmp(data, copy, sizeof(data)) == 0);
}

int main(void) {
    test_room_and_pass();
    test_name();
    test_packet();
    test_hello_payload();
    test_key_and_scramble();
    if (failures) {
        printf("test_app_protocol: %d 项失败\n", failures);
        return 1;
    }
    printf("test_app_protocol: PASS\n");
    return 0;
}

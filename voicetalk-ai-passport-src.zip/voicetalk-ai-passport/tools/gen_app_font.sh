#!/usr/bin/env bash
# 生成 VoiceTalk 界面用的中文字体(默认 16 px,4 bpp,LVGL 格式)。
#
# 为什么要自己生成:LVGL 内置的 lv_font_source_han_sans_sc_16_cjk 只有
# 292 个汉字(CJK 基本区 0x4E4B..0x6E4C),连"房""间""设""置"都没有,
# 而本项目的界面是中文的、使用者名称还能填汉字。
#
# 前置:
#   sudo apt-get install -y fonts-noto-cjk     # 字体源(Noto Sans CJK SC, OFL)
#   npm install -g lv_font_conv                # 官方转换器
#
# 用法:
#   ./tools/gen_app_font.sh                    # 用系统里的 Noto Sans CJK
#   ./tools/gen_app_font.sh /path/to/font.otf  # 指定别的字体
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "${HERE}")"
FONT_DIR="${ROOT}/assets/fonts"
SYMBOLS="${FONT_DIR}/app_font_symbols.txt"

# 系统里 fonts-noto-cjk 是 .ttc 集合;lv_font_conv 只吃单字体,
# 因此先用 fontTools 把其中的 SC 子字体抽出来。
TTC="/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
EXTRACTED="/tmp/NotoSansSC-Regular.otf"

if [ "$#" -ge 1 ]; then
    SRC_FONT="$1"
else
    SRC_FONT="${EXTRACTED}"
    if [ ! -f "${SRC_FONT}" ]; then
        python3 - <<'PY'
from fontTools.ttLib import TTCollection
import sys
collection = TTCollection("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")
for font in collection.fonts:
    if font["name"].getDebugName(1) == "Noto Sans CJK SC":
        font.save("/tmp/NotoSansSC-Regular.otf")
        break
else:
    print("找不到 Noto Sans CJK SC 子字体", file=sys.stderr)
    raise SystemExit(1)
PY
    fi
fi

[ -f "${SRC_FONT}" ] || { echo "错误: 字体不存在 ${SRC_FONT}" >&2; exit 1; }

mkdir -p "${FONT_DIR}"
python3 "${HERE}/gen_app_font_symbols.py" > "${SYMBOLS}"
echo "字符清单: ${SYMBOLS} ($(python3 -c "print(len(open('${SYMBOLS}',encoding='utf-8').read()))") 个字符)"

SYMS="$(cat "${SYMBOLS}")"

# 界面目前只用 16 px。要更大的中文字号(比如给发话提示)时:
#   SIZES="16 20" ./tools/gen_app_font.sh
# 再把对应的 .c 加进 main/CMakeLists.txt,并在 app_ui.c 里 LV_FONT_DECLARE。
SIZES="${SIZES:-16}"
for SIZE in ${SIZES}; do
    echo "==> 生成 app_font_${SIZE}"
    lv_font_conv \
        --font "${SRC_FONT}" \
        --symbols "${SYMS}" \
        --size "${SIZE}" --bpp 4 --format lvgl --no-compress \
        --lv-font-name "app_font_${SIZE}" --lv-include lvgl.h \
        --output "${FONT_DIR}/app_font_${SIZE}.c"
    ls -la "${FONT_DIR}/app_font_${SIZE}.c"
done

cat <<EOF

生成完成。请确认:
  1. git diff 里能看到 app_font_*.c 的变化(只提交界面真正用到的字号);
  2. main/CMakeLists.txt 已把这些 .c 加进编译;
  3. 界面上新增的汉字都在 ${SYMBOLS} 里,否则要重新生成本字体。
EOF

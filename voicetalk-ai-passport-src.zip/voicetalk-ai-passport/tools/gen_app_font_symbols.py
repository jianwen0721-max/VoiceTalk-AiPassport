#!/usr/bin/env python3
"""生成 VoiceTalk 界面字体的字符清单。

字符清单必须进版本控制:界面文案改了、或者要支持新的用户名汉字,
都要重新生成字体,否则设备上会显示占位方框(LVGL 的 placeholder)。

覆盖范围:
  * ASCII 可打印字符(数字、英文、常见符号)
  * GB2312 中的简体汉字(一级 + 二级,共 6763 字)
    —— 使用者名称允许中文,人名用字基本都在这里面;GB2312 之外的
       生僻字会显示占位符,这是当前字库的明确边界。
  * 界面用到的中文标点与少量符号

用法:
    python3 tools/gen_app_font_symbols.py > assets/fonts/app_font_symbols.txt
"""
from __future__ import annotations

import sys


def gb2312_chars(high_range: range, low_range: range) -> list[str]:
    out: list[str] = []
    for hi in high_range:
        for lo in low_range:
            try:
                out.append(bytes([hi, lo]).decode("gb2312"))
            except UnicodeDecodeError:
                continue
    return out


def main() -> int:
    chars: list[str] = []

    # 1) ASCII 可打印字符
    chars.extend(chr(c) for c in range(0x20, 0x7F))

    # 2) 界面文案用到的中文标点与符号(不在这份清单里的标点会变成方框)
    chars.extend(list("，。、；：？！（）《》【】“”‘’—…·％～℃°×→←↑↓□■"))

    # 3) GB2312 简体汉字:一级(0xB0-0xD7)+ 二级(0xD8-0xF7)
    chars.extend(gb2312_chars(range(0xB0, 0xF8), range(0xA1, 0xFF)))

    # 去重并保持顺序稳定(重新生成时输出不变,便于 diff)
    seen: set[str] = set()
    ordered = [c for c in chars if not (c in seen or seen.add(c))]

    sys.stdout.write("".join(ordered))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
